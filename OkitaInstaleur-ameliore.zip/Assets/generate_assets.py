from pathlib import Path
import math
import random
import wave

from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = Path(__file__).resolve().parent
WIDTH, HEIGHT = 1920, 1080


def font(size, bold=False):
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf",
    ]
    for candidate in candidates:
        if Path(candidate).exists():
            return ImageFont.truetype(candidate, size)
    return ImageFont.load_default()


def gradient(size, left, right, vertical=False):
    image = Image.new("RGB", size)
    pixels = image.load()
    width, height = size
    span = max(1, height if vertical else width)
    for y in range(height):
        for x in range(width):
            position = (y if vertical else x) / span
            position = max(0.0, min(1.0, position))
            color = tuple(int(left[i] * (1 - position) + right[i] * position) for i in range(3))
            pixels[x, y] = color
    return image


def logo_image(size):
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    tile = (size - round(size * 0.03125)) // 2
    gap = round(size * 0.03125)
    colors = [((0, 120, 212), (0, 180, 255)), ((30, 90, 168), (123, 104, 238)), ((91, 44, 156), (155, 89, 182)), ((142, 68, 173), (0, 206, 209))]
    positions = [(0, 0), (tile + gap, 0), (0, tile + gap), (tile + gap, tile + gap)]
    for index, ((x, y), (start, end)) in enumerate(zip(positions, colors)):
        tile_image = gradient((tile, tile), start, end)
        mask = Image.new("L", (tile, tile), 0)
        ImageDraw.Draw(mask).rounded_rectangle((0, 0, tile - 1, tile - 1), radius=max(2, size // 128), fill=255)
        canvas.paste(tile_image, (x, y), mask)
        shine = Image.new("RGBA", (tile, tile), (255, 255, 255, 0))
        shine_draw = ImageDraw.Draw(shine)
        shine_draw.ellipse((-tile // 3, -tile // 2, tile, tile // 2), fill=(255, 255, 255, 34))
        shine.putalpha(Image.composite(shine.getchannel("A"), Image.new("L", (tile, tile), 0), mask))
        canvas.alpha_composite(shine, (x, y))
    return canvas


def write_svg():
    ROOT.joinpath("logo_okita.svg").write_text('''<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256" viewBox="0 0 256 256">
  <defs>
    <linearGradient id="a" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#0078D4"/><stop offset="1" stop-color="#00B4FF"/></linearGradient>
    <linearGradient id="b" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#1E5AA8"/><stop offset="1" stop-color="#7B68EE"/></linearGradient>
    <linearGradient id="c" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#5B2C9C"/><stop offset="1" stop-color="#9B59B6"/></linearGradient>
    <linearGradient id="d" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#8E44AD"/><stop offset="1" stop-color="#00CED1"/></linearGradient>
  </defs>
  <rect width="120" height="120" rx="2" fill="url(#a)"/><rect x="136" width="120" height="120" rx="2" fill="url(#b)"/>
  <rect y="136" width="120" height="120" rx="2" fill="url(#c)"/><rect x="136" y="136" width="120" height="120" rx="2" fill="url(#d)"/>
</svg>\n''', encoding="utf-8")


def add_atmosphere(image, seed, accent, title=None, subtitle=None):
    random.seed(seed)
    width, height = image.size
    glow = Image.new("RGBA", image.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(glow)
    for radius in range(520, 20, -20):
        alpha = int(2 + (520 - radius) * 0.035)
        draw.ellipse((width * 0.52 - radius, height * 0.5 - radius, width * 0.52 + radius, height * 0.5 + radius), fill=(*accent, alpha))
    glow = glow.filter(ImageFilter.GaussianBlur(35))
    image = Image.alpha_composite(image.convert("RGBA"), glow)
    draw = ImageDraw.Draw(image, "RGBA")
    for _ in range(150):
        x, y = random.randrange(width), random.randrange(height)
        radius = random.choice([1, 1, 2, 3])
        draw.ellipse((x - radius, y - radius, x + radius, y + radius), fill=(*accent, random.randrange(35, 150)))
    for x in range(-height, width, 90):
        draw.line((x, 0, x + height, height), fill=(*accent, 22), width=1)
    if title:
        draw.text((100, 850), title, font=font(48, True), fill=(245, 248, 255, 235))
    if subtitle:
        draw.text((105, 915), subtitle, font=font(24), fill=(180, 195, 215, 220))
    return image.convert("RGB")


def make_slides():
    base = gradient((WIDTH, HEIGHT), (5, 11, 25), (20, 8, 40), vertical=True)
    splash = add_atmosphere(base.copy(), 1, (0, 170, 255))
    logo = logo_image(320)
    splash.paste(logo, ((WIDTH - logo.width) // 2, 250), logo)
    draw = ImageDraw.Draw(splash)
    draw.text((100, 965), "okitaInstalleur Office", font=font(42, True), fill=(245, 248, 255))
    draw.text((WIDTH - 240, 1010), "by okitakoy", font=font(22), fill=(180, 190, 205))
    splash.save(ROOT / "splash.jpg", quality=93, optimize=True)

    for number, (colors, accent, title, subtitle) in enumerate([
        (((5, 16, 42), (10, 52, 105)), (0, 150, 255), "Choisissez votre version d'Office", "Une installation LTSC claire, rapide et maitrisee"),
        (((23, 8, 48), (5, 55, 72)), (0, 206, 209), "Personnalisez votre installation", "Langue, mises a jour et options selon vos besoins"),
        (((8, 18, 42), (45, 12, 70)), (123, 104, 238), "Selectionnez vos applications", "Installez uniquement les outils dont vous avez besoin"),
    ], start=1):
        image = gradient((WIDTH, HEIGHT), colors[0], colors[1], vertical=True)
        draw = ImageDraw.Draw(image, "RGBA")
        random.seed(number * 11)
        for _ in range(18):
            x, y = random.randrange(WIDTH), random.randrange(HEIGHT)
            size = random.randrange(80, 300)
            draw.rounded_rectangle((x, y, x + size, y + size), radius=12, outline=(*accent, 45), width=3)
        image = add_atmosphere(image, number + 2, accent, title, subtitle)
        image.save(ROOT / f"slide{number}.jpg", quality=93, optimize=True)


def make_audio():
    sample_rate, seconds = 44100, 45
    notes = [110.0, 164.81, 220.0, 261.63, 329.63]
    with wave.open(str(ROOT / "music.wav"), "wb") as output:
        output.setnchannels(1)
        output.setsampwidth(2)
        output.setframerate(sample_rate)
        for index in range(sample_rate * seconds):
            time = index / sample_rate
            pulse = 0.5 + 0.5 * math.sin(2 * math.pi * 0.08 * time)
            sample = sum(math.sin(2 * math.pi * note * time) for note in notes) / len(notes)
            sample += 0.12 * math.sin(2 * math.pi * 55 * time)
            fade = min(1.0, time / 2, (seconds - time) / 2)
            value = int(max(-1, min(1, sample * (0.12 + pulse * 0.05) * fade)) * 32767)
            output.writeframesraw(value.to_bytes(2, "little", signed=True))


if __name__ == "__main__":
    write_svg()
    logo_image(512).save(ROOT / "logo_okita.png", format="PNG", optimize=True)
    logo_image(256).save(ROOT / "icon.ico", format="ICO", sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
    make_slides()
    make_audio()
    print("Assets generated in", ROOT)
