using System.Drawing.Drawing2D;

namespace OkitaInstalleurOffice.Classes;

/// <summary>
/// Palette et primitives visuelles partagées par tout l'installateur. Le langage graphique
/// s'inspire du Fluent Design de Windows 11 (toile de fond neutre, cartes blanches à coins
/// arrondis, accent unique, hiérarchie typographique nette) et de la sobriété des interfaces
/// Apple/macOS (beaucoup de respiration, peu de bruit visuel, un seul appel à l'action fort
/// par écran).
/// </summary>
public static class Theme
{
    // Toile de fond neutre, façon Windows 11 "Mica" clair ou Réglages Système macOS.
    public static readonly Color Canvas = Color.FromArgb(243, 243, 246);
    public static readonly Color CardBackground = Color.White;
    public static readonly Color CardBorder = Color.FromArgb(226, 226, 231);
    public static readonly Color Divider = Color.FromArgb(235, 235, 239);

    public static readonly Color Accent = Color.FromArgb(0, 103, 192);
    public static readonly Color AccentHover = Color.FromArgb(20, 126, 214);
    public static readonly Color AccentPressed = Color.FromArgb(0, 84, 158);

    public static readonly Color Success = Color.FromArgb(16, 137, 71);
    public static readonly Color SuccessHover = Color.FromArgb(24, 156, 84);
    public static readonly Color SuccessPressed = Color.FromArgb(12, 112, 58);

    public static readonly Color Danger = Color.FromArgb(196, 43, 28);
    public static readonly Color DangerHover = Color.FromArgb(216, 63, 47);
    public static readonly Color DangerPressed = Color.FromArgb(163, 33, 20);

    public static readonly Color WarningBackground = Color.FromArgb(255, 244, 206);
    public static readonly Color WarningBorder = Color.FromArgb(228, 195, 105);
    public static readonly Color WarningText = Color.FromArgb(105, 74, 5);

    public static readonly Color DangerBackground = Color.FromArgb(253, 231, 227);
    public static readonly Color DangerBorder = Color.FromArgb(226, 168, 157);
    public static readonly Color DangerText = Color.FromArgb(122, 27, 17);

    public static readonly Color TextPrimary = Color.FromArgb(32, 31, 36);
    public static readonly Color TextSecondary = Color.FromArgb(96, 94, 105);
    public static readonly Color TextMuted = Color.FromArgb(140, 140, 148);
    public static readonly Color TextOnAccent = Color.White;

    public static readonly Color Disabled = Color.FromArgb(232, 232, 236);
    public static readonly Color DisabledText = Color.FromArgb(168, 168, 174);

    public static readonly Font TitleFont = new("Segoe UI", 22f, FontStyle.Bold);
    public static readonly Font SubtitleFont = new("Segoe UI", 10.5f);
    public static readonly Font HeadingFont = new("Segoe UI", 11.5f, FontStyle.Bold);
    public static readonly Font BodyFont = new("Segoe UI", 9.5f);
    public static readonly Font SmallFont = new("Segoe UI", 8.5f);
    public static readonly Font ButtonFont = new("Segoe UI", 10.5f, FontStyle.Bold);

    public const int CardRadius = 10;
    public const int ButtonRadius = 8;

    /// <summary>Construit un chemin d'angles arrondis pour dessiner cartes et boutons.</summary>
    public static GraphicsPath RoundedRect(RectangleF bounds, float radius)
    {
        var path = new GraphicsPath();
        if (radius <= 0f || bounds.Width <= 0f || bounds.Height <= 0f)
        {
            if (bounds.Width > 0f && bounds.Height > 0f) path.AddRectangle(bounds);
            return path;
        }

        radius = Math.Min(radius, Math.Min(bounds.Width, bounds.Height) / 2f);
        var diameter = radius * 2f;
        var arc = new RectangleF(bounds.Location, new SizeF(diameter, diameter));

        path.AddArc(arc, 180, 90);
        arc.X = bounds.Right - diameter;
        path.AddArc(arc, 270, 90);
        arc.Y = bounds.Bottom - diameter;
        path.AddArc(arc, 0, 90);
        arc.X = bounds.Left;
        path.AddArc(arc, 90, 90);
        path.CloseFigure();
        return path;
    }

    /// <summary>Style flat + palette claire pour un ComboBox natif, cohérent avec la carte qui l'entoure.</summary>
    public static void StyleComboBox(ComboBox box)
    {
        box.FlatStyle = FlatStyle.Flat;
        box.BackColor = Color.White;
        box.ForeColor = TextPrimary;
        box.Font = BodyFont;
    }

    /// <summary>Style pour une case à cocher cohérente avec la typographie de l'application.</summary>
    public static void StyleCheckBox(CheckBox box)
    {
        box.ForeColor = TextPrimary;
        box.Font = BodyFont;
        box.FlatStyle = FlatStyle.Standard;
        box.Cursor = Cursors.Hand;
    }
}

/// <summary>Type de mise en avant visuelle d'un <see cref="RoundedButton"/>.</summary>
public enum ButtonKind
{
    /// <summary>Appel à l'action principal de l'écran : fond plein couleur accent.</summary>
    Primary,
    /// <summary>Action secondaire : fond clair avec bordure fine.</summary>
    Secondary,
    /// <summary>Action destructive/d'arrêt : fond plein rouge.</summary>
    Danger,
    /// <summary>Action discrète sans bordure (icônes, bascules).</summary>
    Ghost
}

/// <summary>
/// Bouton à coins arrondis dessiné à la main (WinForms n'a pas de coins arrondis natifs).
/// Le contrôle efface son fond avec <see cref="SurfaceColor"/> (la couleur du conteneur direct)
/// puis dessine par-dessus une forme arrondie : c'est ce qui donne l'illusion de coins ronds
/// sur un fond de conteneur uni, sans dépendre de la transparence GDI+.
/// </summary>
public sealed class RoundedButton : Button
{
    private bool hovered;
    private bool pressed;

    private ButtonKind kindValue = ButtonKind.Secondary;

    public ButtonKind Kind
    {
        get => kindValue;
        set { kindValue = value; Invalidate(); }
    }

    /// <summary>Couleur du conteneur direct, utilisée pour effacer les coins hors de la forme arrondie.</summary>
    public Color SurfaceColor { get; set; } = Theme.Canvas;

    public RoundedButton()
    {
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        FlatStyle = FlatStyle.Flat;
        FlatAppearance.BorderSize = 0;
        Font = Theme.ButtonFont;
        Cursor = Cursors.Hand;
        Height = 42;
        Margin = new Padding(6);
        TabStop = true;

        MouseEnter += (_, _) => { hovered = true; Invalidate(); };
        MouseLeave += (_, _) => { hovered = false; pressed = false; Invalidate(); };
        MouseDown += (_, _) => { pressed = true; Invalidate(); };
        MouseUp += (_, _) => { pressed = false; Invalidate(); };
        EnabledChanged += (_, _) => Invalidate();
    }

    protected override void OnPaintBackground(PaintEventArgs pevent) => pevent.Graphics.Clear(SurfaceColor);

    protected override void OnTextChanged(EventArgs e)
    {
        base.OnTextChanged(e);
        Invalidate();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        var graphics = e.Graphics;
        graphics.SmoothingMode = SmoothingMode.AntiAlias;

        var bounds = new RectangleF(0.5f, 0.5f, Width - 1, Height - 1);
        using var path = Theme.RoundedRect(bounds, Theme.ButtonRadius);
        var (fill, border, text) = ResolveColors();

        using (var brush = new SolidBrush(fill)) graphics.FillPath(brush, path);
        if (border.HasValue)
        {
            using var pen = new Pen(border.Value, 1f);
            graphics.DrawPath(pen, path);
        }

        var textRect = Rectangle.Round(bounds);
        TextRenderer.DrawText(graphics, Text, Font, textRect, text,
            TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding | TextFormatFlags.EndEllipsis);
    }

    private (Color Fill, Color? Border, Color Text) ResolveColors()
    {
        if (!Enabled) return (Theme.Disabled, null, Theme.DisabledText);

        return Kind switch
        {
            ButtonKind.Primary => (pressed ? Theme.AccentPressed : hovered ? Theme.AccentHover : Theme.Accent, null, Theme.TextOnAccent),
            ButtonKind.Danger => (pressed ? Theme.DangerPressed : hovered ? Theme.DangerHover : Theme.Danger, null, Theme.TextOnAccent),
            ButtonKind.Ghost => (pressed ? AdjustForHover(SurfaceColor, 20) : hovered ? AdjustForHover(SurfaceColor, 10) : SurfaceColor, null, IsDarkSurface(SurfaceColor) ? Color.White : Theme.TextPrimary),
            _ => (pressed ? Color.FromArgb(230, 230, 235) : hovered ? Color.FromArgb(240, 240, 244) : Theme.CardBackground, Theme.CardBorder, Theme.TextPrimary)
        };
    }

    /// <summary>Un bouton "ghost" doit s'éclaircir au survol sur une surface sombre (bandeau photo)
    /// et s'assombrir légèrement sur une surface claire (carte blanche) : on choisit le sens
    /// d'après la luminance perçue de la couleur de fond fournie.</summary>
    private static bool IsDarkSurface(Color color) => 0.299 * color.R + 0.587 * color.G + 0.114 * color.B < 140;

    private static Color AdjustForHover(Color color, int amount) => IsDarkSurface(color) ? Lighten(color, amount) : Darken(color, amount);

    private static Color Lighten(Color color, int amount) => Color.FromArgb(
        color.A,
        Math.Min(255, color.R + amount),
        Math.Min(255, color.G + amount),
        Math.Min(255, color.B + amount));

    private static Color Darken(Color color, int amount) => Color.FromArgb(
        color.A,
        Math.Max(0, color.R - amount),
        Math.Max(0, color.G - amount),
        Math.Max(0, color.B - amount));
}

/// <summary>
/// Carte blanche à coins arrondis avec bordure fine et titre optionnel, utilisée à la place
/// des <see cref="GroupBox"/> natifs (qui rendent mal une fois le thème sombre par défaut de
/// Windows appliqué et rompent l'identité visuelle propre de l'application).
/// </summary>
public sealed class Card : Panel
{
    private string? header;

    public string? Header
    {
        get => header;
        set { header = value; UpdatePadding(); Invalidate(); }
    }

    /// <summary>Couleur de fond du conteneur direct, pour effacer proprement les coins hors carte.</summary>
    public Color SurfaceColor { get; set; } = Theme.Canvas;

    public Color BorderColor { get; set; } = Theme.CardBorder;

    public Card()
    {
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        BackColor = Theme.CardBackground;
        UpdatePadding();
    }

    private void UpdatePadding() => Padding = new Padding(18, string.IsNullOrEmpty(header) ? 16 : 46, 18, 16);

    protected override void OnPaintBackground(PaintEventArgs pevent) => pevent.Graphics.Clear(SurfaceColor);

    protected override void OnPaint(PaintEventArgs e)
    {
        var graphics = e.Graphics;
        graphics.SmoothingMode = SmoothingMode.AntiAlias;

        var bounds = new RectangleF(0.5f, 0.5f, Width - 1, Height - 1);
        using var path = Theme.RoundedRect(bounds, Theme.CardRadius);
        using (var brush = new SolidBrush(BackColor)) graphics.FillPath(brush, path);
        using (var pen = new Pen(BorderColor, 1f)) graphics.DrawPath(pen, path);

        if (!string.IsNullOrEmpty(header))
        {
            using var textBrush = new SolidBrush(Theme.TextPrimary);
            graphics.DrawString(header, Theme.HeadingFont, textBrush, new PointF(18, 14));
        }

        base.OnPaint(e);
    }
}
