using NAudio.Wave;

namespace OkitaInstalleurOffice.Classes;

public sealed class AudioManager : IDisposable
{
    private IWavePlayer? output;
    private AudioFileReader? reader;
    private IWavePlayer? effectOutput;
    private float lastVolume = 0.4f;

    public bool IsPlaying { get; private set; }
    public bool IsMuted { get; private set; }

    public void PlayLoop(string path, float volume = 0.4f, bool startMuted = false)
    {
        lastVolume = Math.Clamp(volume, 0f, 1f);
        IsMuted = startMuted;
        try
        {
            var audioPath = File.Exists(path) ? path : AssetLoader.ExtractAudio(path, "music.wav");
            if (audioPath is null)
            {
                Logger.Warn("Aucune piste audio disponible (ni fichier local, ni ressource embarquée) : musique désactivée.");
                return;
            }
            reader = new AudioFileReader(audioPath) { Volume = IsMuted ? 0f : lastVolume };
            output = new WaveOutEvent();
            output.Init(new LoopStream(reader));
            output.Play();
            IsPlaying = true;
        }
        catch (Exception exception)
        {
            // Une erreur audio ne doit jamais bloquer l'installateur : on journalise et on continue en silence.
            Logger.Warn($"Lecture audio impossible, l'application continue sans musique : {exception.Message}");
            Dispose();
        }
    }

    public void SetMuted(bool muted)
    {
        IsMuted = muted;
        if (reader is not null) reader.Volume = muted ? 0f : lastVolume;
    }

    public void ToggleMute() => SetMuted(!IsMuted);

    public void SetVolume(float volume)
    {
        lastVolume = Math.Clamp(volume, 0f, 1f);
        if (reader is not null && !IsMuted) reader.Volume = lastVolume;
    }

    public void FadeOut(int milliseconds = 700)
    {
        if (reader is null) return;
        const int steps = 10;
        var delay = Math.Max(1, milliseconds / steps);
        for (var index = steps; index >= 0; index--)
        {
            reader.Volume = IsMuted ? 0f : lastVolume * index / steps;
            Thread.Sleep(delay);
        }
        Dispose();
    }

    /// <summary>
    /// Joue un court signal généré (pas de fichier requis) pour confirmer la fin d'une action :
    /// deux notes montantes pour un succès, une note grave pour un échec. N'a aucun effet si
    /// l'utilisateur a coupé le son.
    /// </summary>
    public void PlayChime(bool success)
    {
        if (IsMuted) return;
        try
        {
            effectOutput?.Dispose();
            var segments = success
                ? new[] { (Frequency: 660d, Milliseconds: 140), (Frequency: 880d, Milliseconds: 170) }
                : new[] { (Frequency: 220d, Milliseconds: 220) };
            effectOutput = new WaveOutEvent();
            effectOutput.Init(new ChimeSampleProvider(segments));
            effectOutput.Play();
        }
        catch
        {
            // Un son de confirmation manqué n'a aucune conséquence fonctionnelle.
        }
    }

    /// <summary>
    /// Générateur de sinusoïdes minimaliste, sans dépendance externe : enchaîne une courte
    /// série de notes avec une enveloppe douce (fade in/out) pour éviter les "clics" audio.
    /// </summary>
    private sealed class ChimeSampleProvider((double Frequency, int Milliseconds)[] segments) : ISampleProvider
    {
        private const int SampleRate = 44100;
        private int segmentIndex;
        private int sampleInSegment;

        public WaveFormat WaveFormat { get; } = WaveFormat.CreateIeeeFloatWaveFormat(SampleRate, 1);

        public int Read(float[] buffer, int offset, int count)
        {
            var written = 0;
            while (written < count && segmentIndex < segments.Length)
            {
                var (frequency, milliseconds) = segments[segmentIndex];
                var totalSamples = SampleRate * milliseconds / 1000;
                var envelopeEdge = Math.Max(1, totalSamples / 8);
                var t = (double)sampleInSegment / SampleRate;
                var envelope = Math.Min(1.0, Math.Min((double)sampleInSegment / envelopeEdge, (double)(totalSamples - sampleInSegment) / envelopeEdge));
                buffer[offset + written] = (float)(Math.Sin(2 * Math.PI * frequency * t) * 0.18 * Math.Clamp(envelope, 0, 1));
                written++;
                sampleInSegment++;
                if (sampleInSegment >= totalSamples)
                {
                    segmentIndex++;
                    sampleInSegment = 0;
                }
            }
            return written;
        }
    }

    public void Dispose()
    {
        output?.Stop();
        output?.Dispose();
        reader?.Dispose();
        effectOutput?.Stop();
        effectOutput?.Dispose();
        output = null;
        reader = null;
        effectOutput = null;
        IsPlaying = false;
    }

    private sealed class LoopStream(AudioFileReader source) : WaveStream
    {
        public override WaveFormat WaveFormat => source.WaveFormat;
        public override long Length => long.MaxValue;
        public override long Position { get => source.Position; set => source.Position = value; }
        public override int Read(byte[] buffer, int offset, int count)
        {
            var read = source.Read(buffer, offset, count);
            if (read == 0)
            {
                source.Position = 0;
                read = source.Read(buffer, offset, count);
            }
            return read;
        }
    }
}
