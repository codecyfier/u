namespace OkitaInstalleurOffice.Classes;

/// <summary>
/// Traduit les codes de sortie les plus fréquents de setup.exe (ODT) et de Windows
/// en un message clair en français, avec une suggestion d'action quand c'est possible.
/// </summary>
public static class ExitCodeTranslator
{
    public static string Describe(int exitCode)
    {
        return exitCode switch
        {
            0 => "Succès.",
            1 => "Échec général signalé par ODT. Consultez le journal détaillé pour la cause exacte.",
            5 => "Accès refusé. Relancez l'application en tant qu'administrateur.",
            17002 => "Erreur réseau : ODT n'a pas pu contacter les serveurs Microsoft. Vérifiez votre connexion Internet et vos éventuels pare-feux/proxys.",
            17003 => "Fichiers d'installation corrompus ou incomplets. Supprimez %TEMP%\\okitaInstaller puis relancez.",
            30015 => "Une autre installation Office est déjà en cours. Attendez qu'elle se termine puis relancez.",
            30088 => "Une version d'Office déjà installée bloque le déploiement. Désinstallez l'ancienne version au préalable.",
            30180 => "Le fichier de configuration XML généré est invalide.",
            _ when exitCode < 0 => $"Erreur système Windows (code {exitCode}). Le processus setup.exe a peut-être été interrompu de façon inattendue.",
            _ => $"ODT a retourné le code de sortie {exitCode}. Consultez le journal pour le détail complet de la sortie."
        };
    }
}
