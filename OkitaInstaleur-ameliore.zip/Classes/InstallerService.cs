using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;

namespace OkitaInstalleurOffice.Classes;

public sealed partial class InstallerService
{
    private const int ProcessStartPercent = 30;
    private const int SimulatedCapPercent = 92;

    public async Task InstallAsync(OfficeConfig config, IProgress<string> progress, CancellationToken cancellationToken = default)
    {
        Logger.Info($"Démarrage de l'installation : version={config.Version}, langue={config.Language}, architecture={config.Architecture}, applications exclues=[{string.Join(",", config.ExcludedApps)}]");

        var extractor = new ResourceExtractor();
        progress.Report("5|Vérifications préalables...|Contrôle de l'espace disque et de la connexion");
        cancellationToken.ThrowIfCancellationRequested();

        progress.Report("10|Préparation des fichiers...|Réutilisation de setup.exe en cache si disponible");
        string setupPath;
        try
        {
            setupPath = extractor.ExtractSetup();
        }
        catch (Exception exception)
        {
            Logger.Error("Échec de l'extraction de setup.exe", exception);
            throw;
        }

        var xmlPath = Path.Combine(extractor.TemporaryDirectory, "configuration.xml");
        progress.Report("20|Génération de la configuration...|Création de configuration.xml");
        try
        {
            XmlGenerator.Write(xmlPath, config);
            Logger.Info($"configuration.xml généré : {xmlPath}");
        }
        catch (Exception exception)
        {
            Logger.Error("Échec de la génération de configuration.xml", exception);
            throw new InvalidOperationException("Impossible de générer le fichier de configuration XML. Vérifiez les droits d'écriture sur %TEMP%.", exception);
        }
        cancellationToken.ThrowIfCancellationRequested();

        progress.Report($"{ProcessStartPercent}|Connexion au programme d'installation Office...|ODT peut nécessiter plusieurs minutes selon la connexion");
        await RunSetupProcessAsync(setupPath, xmlPath, extractor.TemporaryDirectory, progress, cancellationToken);

        progress.Report("100|Terminé !|Installation Office terminée avec succès");
        Logger.Info("Installation terminée avec succès.");
    }

    private static async Task RunSetupProcessAsync(string setupPath, string xmlPath, string workingDirectory, IProgress<string> progress, CancellationToken cancellationToken)
    {
        var process = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = setupPath,
                Arguments = $"/configure \"{xmlPath}\"",
                WorkingDirectory = workingDirectory,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            },
            EnableRaisingEvents = true
        };

        var outputLog = new StringBuilder();
        var simulatedPercent = ProcessStartPercent;
        var parsedPercent = 0;
        var percentLock = new object();

        process.OutputDataReceived += (_, args) => HandleOutputLine(args.Data, outputLog, ref parsedPercent, percentLock, progress);
        process.ErrorDataReceived += (_, args) => HandleOutputLine(args.Data, outputLog, ref parsedPercent, percentLock, progress);

        if (!process.Start())
        {
            Logger.Error("Impossible de démarrer setup.exe (Process.Start a retourné false).");
            throw new InvalidOperationException("Impossible de démarrer setup.exe.");
        }

        using var cancellationRegistration = cancellationToken.Register(() =>
        {
            try
            {
                if (!process.HasExited) process.Kill(true);
                Logger.Warn("Installation annulée par l'utilisateur : processus setup.exe arrêté.");
            }
            catch (InvalidOperationException) { }
        });

        process.BeginOutputReadLine();
        process.BeginErrorReadLine();
        progress.Report($"{ProcessStartPercent}|Installation en cours...|Téléchargement et installation gérés par Microsoft ODT");

        // ODT ne fournit pas de pourcentage fiable dans la majorité des cas : on simule une
        // progression fluide et crédible pendant l'attente, sans jamais dépasser un plafond,
        // et on laisse la priorité à un pourcentage réel dès qu'on en détecte un dans la sortie.
        using var simulationCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        var simulationTask = Task.Run(async () =>
        {
            try
            {
                while (!simulationCts.IsCancellationRequested)
                {
                    await Task.Delay(700, simulationCts.Token);
                    lock (percentLock)
                    {
                        if (simulatedPercent < SimulatedCapPercent) simulatedPercent++;
                        var effective = Math.Max(simulatedPercent, parsedPercent);
                        progress.Report($"{effective}|Installation en cours...|Téléchargement et installation gérés par Microsoft ODT");
                    }
                }
            }
            catch (OperationCanceledException) { }
        }, cancellationToken);

        try
        {
            await process.WaitForExitAsync(cancellationToken);
        }
        finally
        {
            simulationCts.Cancel();
            try { await simulationTask; } catch (OperationCanceledException) { }
        }

        Logger.Info($"setup.exe terminé avec le code {process.ExitCode}.");
        if (outputLog.Length > 0)
            Logger.Info($"Sortie complète d'ODT :\n{outputLog}");

        if (process.ExitCode != 0)
        {
            var description = ExitCodeTranslator.Describe(process.ExitCode);
            throw new InvalidOperationException($"L'installation Office a échoué (code {process.ExitCode}). {description}");
        }
    }

    private static void HandleOutputLine(string? data, StringBuilder outputLog, ref int parsedPercent, object percentLock, IProgress<string> progress)
    {
        if (string.IsNullOrWhiteSpace(data)) return;
        outputLog.AppendLine(data);

        var match = PercentPattern().Match(data);
        if (match.Success && int.TryParse(match.Groups[1].Value, out var value))
        {
            lock (percentLock)
            {
                parsedPercent = Math.Max(parsedPercent, Math.Clamp(value, ProcessStartPercent, 99));
            }
        }
    }

    [GeneratedRegex(@"(\d{1,3})\s?%")]
    private static partial Regex PercentPattern();
}
