namespace OkitaInstalleurOffice.Classes;

public sealed class OfficeConfig
{
    public string Version { get; set; } = "ProPlus2024Volume";
    public string Language { get; set; } = "fr-fr";
    public List<string> ExcludedApps { get; set; } = new();
    public bool AutoAcceptEULA { get; set; } = true;
    public bool ForceShutdown { get; set; } = true;
    public bool EnableUpdates { get; set; } = true;
    public int Architecture { get; set; } = 64;

    public string Channel => Version switch
    {
        "ProPlus2024Volume" => "PerpetualVL2024",
        "ProPlus2021Volume" => "PerpetualVL2021",
        _ => "PerpetualVL2019"
    };
}
