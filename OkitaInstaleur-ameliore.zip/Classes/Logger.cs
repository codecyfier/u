using System.Text;

namespace OkitaInstalleurOffice.Classes;

/// <summary>
/// Journalisation fichier simple et thread-safe. Chaque exécution écrit dans un fichier
/// horodaté sous %TEMP%\okitaInstaller\logs afin de pouvoir diagnostiquer un échec
/// d'installation après coup, y compris la sortie complète d'ODT.
/// </summary>
public static class Logger
{
    private static readonly object WriteLock = new();
    private static readonly StringBuilder Buffer = new();

    public static string Directory { get; } = Path.Combine(Path.GetTempPath(), "okitaInstaller", "logs");

    public static string FilePath { get; } = Path.Combine(Directory, $"okita-{DateTime.Now:yyyyMMdd-HHmmss}.log");

    public static void Info(string message) => Write("INFO", message);

    public static void Warn(string message) => Write("WARN", message);

    public static void Error(string message) => Write("ERROR", message);

    public static void Error(string message, Exception exception) => Write("ERROR", $"{message} :: {exception.GetType().Name}: {exception.Message}\n{exception.StackTrace}");

    /// <summary>Contenu du journal accumulé pendant cette exécution (pour copie presse-papiers).</summary>
    public static string CurrentSessionText
    {
        get
        {
            lock (WriteLock) return Buffer.ToString();
        }
    }

    private static void Write(string level, string message)
    {
        var line = $"[{DateTime.Now:HH:mm:ss.fff}] [{level}] {message}";
        lock (WriteLock)
        {
            Buffer.AppendLine(line);
            try
            {
                System.IO.Directory.CreateDirectory(Directory);
                File.AppendAllText(FilePath, line + Environment.NewLine, Encoding.UTF8);
            }
            catch
            {
                // L'écriture du journal ne doit jamais faire planter l'application :
                // au pire, il reste consultable en mémoire via CurrentSessionText.
            }
        }
    }
}
