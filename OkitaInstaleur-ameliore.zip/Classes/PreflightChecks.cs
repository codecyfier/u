using System.Net.Sockets;
using System.Reflection;

namespace OkitaInstalleurOffice.Classes;

public enum PreflightSeverity { Info, Warning, Blocking }

public readonly record struct PreflightResult(PreflightSeverity Severity, string Message);

/// <summary>
/// Contrôles rapides exécutés avant d'afficher/activer le bouton d'installation,
/// pour échouer tôt avec un message clair plutôt que de laisser l'utilisateur
/// attendre plusieurs minutes avant de découvrir un problème évident.
/// </summary>
public static class PreflightChecks
{
    public static async Task<List<PreflightResult>> RunAsync()
    {
        var results = new List<PreflightResult>();

        results.Add(CheckEmbeddedSetup());
        results.Add(CheckDiskSpace());
        results.Add(CheckOperatingSystem());
        results.Add(await CheckConnectivityAsync());

        foreach (var result in results)
            Logger.Info($"Prévol [{result.Severity}] {result.Message}");

        return results;
    }

    private static PreflightResult CheckEmbeddedSetup()
    {
        var assembly = Assembly.GetExecutingAssembly();
        var hasSetup = assembly.GetManifestResourceNames().Any(name => name.EndsWith("setup.exe", StringComparison.OrdinalIgnoreCase));
        return hasSetup
            ? new PreflightResult(PreflightSeverity.Info, "setup.exe ODT embarqué détecté.")
            : new PreflightResult(PreflightSeverity.Blocking, "Aucun setup.exe ODT n'est embarqué dans cet exécutable. Consultez le README pour l'intégrer avant de publier.");
    }

    private static PreflightResult CheckDiskSpace()
    {
        try
        {
            var drive = new DriveInfo(Path.GetPathRoot(Path.GetTempPath()) ?? "C:\\");
            var freeGb = drive.AvailableFreeSpace / 1024d / 1024d / 1024d;
            if (freeGb < 4)
                return new PreflightResult(PreflightSeverity.Warning, $"Espace disque faible sur {drive.Name} ({freeGb:0.0} Go libres). Office nécessite plusieurs Go.");
            return new PreflightResult(PreflightSeverity.Info, $"Espace disque suffisant ({freeGb:0.0} Go libres).");
        }
        catch (Exception exception)
        {
            return new PreflightResult(PreflightSeverity.Info, $"Impossible de vérifier l'espace disque : {exception.Message}");
        }
    }

    private static PreflightResult CheckOperatingSystem()
    {
        if (!Environment.Is64BitOperatingSystem)
            return new PreflightResult(PreflightSeverity.Warning, "Ce système est en 32 bits : seule l'installation Office 32 bits sera possible.");
        return new PreflightResult(PreflightSeverity.Info, "Système 64 bits détecté.");
    }

    private static async Task<PreflightResult> CheckConnectivityAsync()
    {
        try
        {
            using var client = new TcpClient();
            var connectTask = client.ConnectAsync("officecdn.microsoft.com", 443);
            var timeoutTask = Task.Delay(TimeSpan.FromSeconds(3));
            var finished = await Task.WhenAny(connectTask, timeoutTask);
            if (finished == connectTask && client.Connected)
                return new PreflightResult(PreflightSeverity.Info, "Connexion aux serveurs Microsoft OK.");
            return new PreflightResult(PreflightSeverity.Warning, "Connexion Internet non confirmée. L'installation ODT nécessite un accès réseau aux serveurs Microsoft.");
        }
        catch (Exception exception)
        {
            return new PreflightResult(PreflightSeverity.Warning, $"Connexion Internet non confirmée ({exception.Message}).");
        }
    }
}
