using System.Text.Json;

namespace OkitaInstalleurOffice.Classes;

/// <summary>
/// Préférences utilisateur persistées entre deux exécutions : état du son, volume,
/// et derniers choix effectués dans l'interface pour éviter de tout ressaisir.
/// </summary>
public sealed class AppSettings
{
    private static readonly string FilePath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "okitaInstaller", "settings.json");

    public bool Muted { get; set; }
    public float Volume { get; set; } = 0.4f;
    public int VersionIndex { get; set; }
    public int LanguageIndex { get; set; }
    public List<string> UncheckedApps { get; set; } = new();
    public bool AutoAcceptEula { get; set; } = true;
    public bool ForceShutdown { get; set; } = true;
    public bool EnableUpdates { get; set; } = true;
    public bool Architecture64 { get; set; } = true;

    public static AppSettings Load()
    {
        try
        {
            if (File.Exists(FilePath))
            {
                var json = File.ReadAllText(FilePath);
                var loaded = JsonSerializer.Deserialize<AppSettings>(json);
                if (loaded is not null) return loaded;
            }
        }
        catch (Exception exception)
        {
            Logger.Warn($"Impossible de lire les préférences enregistrées, valeurs par défaut utilisées : {exception.Message}");
        }
        return new AppSettings();
    }

    public void Save()
    {
        try
        {
            var directory = Path.GetDirectoryName(FilePath)!;
            Directory.CreateDirectory(directory);
            var json = JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(FilePath, json);
        }
        catch (Exception exception)
        {
            // Ne jamais bloquer l'installation si l'écriture des préférences échoue
            // (dossier en lecture seule, disque plein, etc.).
            Logger.Warn($"Impossible d'enregistrer les préférences : {exception.Message}");
        }
    }
}
