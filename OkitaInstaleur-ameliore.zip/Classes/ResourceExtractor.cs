using System.Reflection;

namespace OkitaInstalleurOffice.Classes;

public sealed class ResourceExtractor
{
    private static readonly object ExtractionLock = new();
    private const int MaxAttempts = 3;
    public string TemporaryDirectory { get; } = Path.Combine(Path.GetTempPath(), "okitaInstaller");

    public string ExtractSetup()
    {
        lock (ExtractionLock)
        {
            Exception? lastError = null;
            for (var attempt = 1; attempt <= MaxAttempts; attempt++)
            {
                try
                {
                    return ExtractOnce();
                }
                catch (Exception exception) when (exception is IOException or UnauthorizedAccessException)
                {
                    lastError = exception;
                    Logger.Warn($"Extraction de setup.exe échouée (tentative {attempt}/{MaxAttempts}) : {exception.Message}");
                    if (attempt < MaxAttempts) Thread.Sleep(250 * attempt);
                }
            }
            Logger.Error("Extraction de setup.exe impossible après plusieurs tentatives.", lastError!);
            throw new IOException("Impossible d'extraire setup.exe après plusieurs tentatives. Vérifiez les droits sur %TEMP% et qu'aucun antivirus ne bloque le fichier.", lastError);
        }
    }

    private string ExtractOnce()
    {
        Directory.CreateDirectory(TemporaryDirectory);
        var outputPath = Path.Combine(TemporaryDirectory, "setup.exe");
        var assembly = Assembly.GetExecutingAssembly();
        var resourceName = assembly.GetManifestResourceNames().FirstOrDefault(name => name.EndsWith("setup.exe", StringComparison.OrdinalIgnoreCase));
        if (resourceName is null)
            throw new FileNotFoundException("Le fichier setup.exe ODT n'est pas embarqué dans cette version. Consultez le README pour l'intégrer.");

        using var input = assembly.GetManifestResourceStream(resourceName) ?? throw new InvalidOperationException("La ressource setup.exe est illisible.");
        if (IsCachedSetupValid(outputPath, input.Length))
        {
            Logger.Info("setup.exe déjà présent en cache, réutilisation.");
            return outputPath;
        }

        var temporaryPath = outputPath + ".new";
        using (var output = new FileStream(temporaryPath, FileMode.Create, FileAccess.Write, FileShare.None, 1024 * 1024, FileOptions.SequentialScan))
        {
            input.CopyTo(output);
            output.Flush(true);
        }
        File.Move(temporaryPath, outputPath, true);
        if (!IsCachedSetupValid(outputPath, input.Length))
            throw new InvalidDataException("Le fichier setup.exe extrait est vide ou corrompu.");
        Logger.Info($"setup.exe extrait vers {outputPath}.");
        return outputPath;
    }

    private static bool IsCachedSetupValid(string path, long expectedLength)
    {
        if (!File.Exists(path)) return false;
        var fileInfo = new FileInfo(path);
        if (fileInfo.Length != expectedLength || fileInfo.Length < 2) return false;

        try
        {
            using var file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 2, FileOptions.SequentialScan);
            return file.ReadByte() == 'M' && file.ReadByte() == 'Z';
        }
        catch (IOException)
        {
            return false;
        }
    }
}
