using System.Text;
using System.Xml;

namespace OkitaInstalleurOffice.Classes;

public static class XmlGenerator
{
    public static void Write(string path, OfficeConfig config)
    {
        var settings = new XmlWriterSettings { Indent = true, Encoding = new UTF8Encoding(false), OmitXmlDeclaration = false };
        using var writer = XmlWriter.Create(path, settings);
        writer.WriteStartDocument();
        writer.WriteStartElement("Configuration");
        writer.WriteAttributeString("ID", "okita-installer-by-okitakoy");

        writer.WriteStartElement("Add");
        writer.WriteAttributeString("OfficeClientEdition", config.Architecture.ToString());
        writer.WriteAttributeString("Channel", config.Channel);
        writer.WriteStartElement("Product");
        writer.WriteAttributeString("ID", config.Version);
        writer.WriteAttributeString("PIDKEY", ProductKeyFor(config.Version));
        writer.WriteStartElement("Language");
        writer.WriteAttributeString("ID", config.Language);
        writer.WriteEndElement();
        foreach (var app in config.ExcludedApps.Distinct(StringComparer.OrdinalIgnoreCase))
        {
            writer.WriteStartElement("ExcludeApp");
            writer.WriteAttributeString("ID", app);
            writer.WriteEndElement();
        }
        writer.WriteEndElement();
        writer.WriteEndElement();

        WriteProperty(writer, "SharedComputerLicensing", "0");
        WriteProperty(writer, "FORCEAPPSHUTDOWN", config.ForceShutdown ? "TRUE" : "FALSE");
        WriteProperty(writer, "DeviceBasedLicensing", "0");
        WriteProperty(writer, "SCLCacheOverride", "0");
        WriteProperty(writer, "AUTOACTIVATE", "1");
        WriteProperty(writer, "AcceptEULA", config.AutoAcceptEULA ? "TRUE" : "FALSE");

        writer.WriteStartElement("Updates");
        writer.WriteAttributeString("Enabled", config.EnableUpdates ? "TRUE" : "FALSE");
        writer.WriteEndElement();
        writer.WriteStartElement("RemoveMSI");
        writer.WriteEndElement();
        writer.WriteEndElement();
        writer.WriteEndDocument();
    }

    private static void WriteProperty(XmlWriter writer, string name, string value)
    {
        writer.WriteStartElement("Property");
        writer.WriteAttributeString("Name", name);
        writer.WriteAttributeString("Value", value);
        writer.WriteEndElement();
    }

    private static string ProductKeyFor(string version) => version switch
    {
        "ProPlus2024Volume" => "XJ2XN-FW8RK-P4HMP-DKDBV-GCVGB",
        "ProPlus2021Volume" => "FXYTK-NJJ8C-GB6DW-3DYQT-6F7TH",
        _ => "NMMKJ-6RK4F-KMJVX-8D9MJ-6MWKP"
    };
}
