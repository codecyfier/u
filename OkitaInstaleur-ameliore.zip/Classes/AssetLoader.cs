using System.Reflection;

namespace OkitaInstalleurOffice.Classes;

public static class AssetLoader
{
    private static readonly Assembly Assembly = typeof(AssetLoader).Assembly;

    public static Stream? Open(string fileName)
    {
        var resourceName = Assembly.GetManifestResourceNames().FirstOrDefault(name => name.EndsWith(fileName, StringComparison.OrdinalIgnoreCase));
        if (resourceName is not null)
            return Assembly.GetManifestResourceStream(resourceName);

        var path = Path.Combine(AppContext.BaseDirectory, "Assets", fileName);
        return File.Exists(path) ? File.OpenRead(path) : null;
    }

    public static Image? LoadImage(string fileName)
    {
        try
        {
            using var stream = Open(fileName);
            if (stream is null) return null;
            using var source = Image.FromStream(stream);
            return new Bitmap(source);
        }
        catch
        {
            return null;
        }
    }

    public static string? ExtractAudio(params string[] fileNames)
    {
        foreach (var fileName in fileNames)
        {
            try
            {
                using var stream = OpenEmbedded(fileName);
                if (stream is null) continue;
                var path = Path.Combine(Path.GetTempPath(), "okitaInstaller", fileName);
                Directory.CreateDirectory(Path.GetDirectoryName(path)!);
                using var output = File.Create(path);
                stream.CopyTo(output);
                return path;
            }
            catch
            {
                // Une ressource audio indisponible ne doit pas bloquer l'installation.
            }
        }
        return null;
    }

    private static Stream? OpenEmbedded(string fileName)
    {
        var resourceName = Assembly.GetManifestResourceNames().FirstOrDefault(name => name.EndsWith(fileName, StringComparison.OrdinalIgnoreCase));
        return resourceName is null ? null : Assembly.GetManifestResourceStream(resourceName);
    }
}
