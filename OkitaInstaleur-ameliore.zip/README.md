# okitaInstalleur Office

## Version 1.1.0 — Refonte visuelle et durcissement du code

- **Nouvelle identité visuelle claire, inspirée de Fluent Design (Windows 11) et des interfaces Apple/macOS** : toile de fond neutre, cartes blanches à coins arrondis (`Classes/Theme.cs` : `Card`, `RoundedButton`), un seul accent bleu, hiérarchie typographique nette (titre / sous-titre / corps), beaucoup de respiration, un seul bouton d'action fort par écran. Les composants Windows natifs (case à cocher, liste déroulante, curseur de volume, barre de progression) sont conçus par Microsoft pour un thème clair : ils sont maintenant cohérents avec le reste de l'application au lieu de jurer avec un thème sombre personnalisé.
- **Écran principal repensé** : la photo plein écran en fond a été retirée au profit d'un bandeau "hero" en haut de fenêtre (photo + dégradé + titre, façon bannière d'application moderne) ; le contenu (version, langue, applications, options, bouton d'installation) est présenté dans des cartes lisibles sur fond clair, avec défilement automatique si la fenêtre est réduite.
- **Écran de progression repensé** : hiérarchie d'actions plus claire — le bouton principal (accent) est toujours l'action recommandée du moment ("Annuler" en rouge pendant l'installation, "Fermer" en accent après un succès, "Réessayer" mis en avant après un échec), les actions secondaires ("Voir le journal", "Copier le détail") restent discrètes.
- **Composants réutilisables** : `RoundedButton` (boutons à coins arrondis avec états survol/pression/désactivé cohérents) et `Card` (cartes à coins arrondis avec titre optionnel) remplacent les `GroupBox` et boutons plats natifs pour une identité visuelle propre à l'application plutôt que dépendante du thème Windows de l'utilisateur.
- **Correctifs** : le bouton de fermeture de l'écran de progression changeait de couleur "danger" même après une installation réussie ; il reflète maintenant l'issue réelle (succès/annulation/échec). Nettoyage de code mort (image de fond de repli qui n'était plus utilisée).

## Améliorations précédentes

- **Gestion des erreurs rigoureuse** : gestionnaires globaux (`Application.ThreadException`, `AppDomain.UnhandledException`, `TaskScheduler.UnobservedTaskException`) pour qu'aucune exception ne fasse planter l'application silencieusement. Journal fichier complet dans `%TEMP%\okitaInstaller\logs\` (une entrée par exécution, avec toute la sortie d'ODT). Codes de sortie ODT traduits en messages clairs (`Classes/ExitCodeTranslator.cs`). Extraction de `setup.exe` avec 3 tentatives et backoff en cas d'erreur disque/antivirus transitoire.
- **Vérifications préalables** (`Classes/PreflightChecks.cs`) : avant même d'activer le bouton d'installation, l'application contrôle la présence du `setup.exe` embarqué, l'espace disque disponible, l'architecture du système et la connectivité vers les serveurs Microsoft. Les problèmes bloquants désactivent le bouton avec un message explicite ; les avertissements s'affichent dans un bandeau non bloquant.
- **Progression fluide et crédible** : ODT ne fournissant pas de pourcentage fiable, la barre progresse désormais de façon continue et animée (interpolation douce) pendant toute la durée de l'installation, tout en donnant la priorité à un pourcentage réel dès qu'il est détecté dans la sortie du processus. Fini la barre figée à 30 % pendant plusieurs minutes.
- **Écran d'échec exploitable** : en cas d'erreur, l'écran de progression propose "Réessayer" (relance sans redémarrer l'application), "Voir le journal" (ouvre le fichier log) et "Copier le détail" (presse-papiers).
- **Interface musicale** : bouton muet/son et curseur de volume sur l'écran d'accueil et l'écran principal, préférence mémorisée (`%APPDATA%\okitaInstaller\settings.json`). Petits sons de confirmation générés en code (aucun fichier requis) à la fin d'une installation réussie ou échouée.
- **Design** : boutons avec véritables effets de survol/clic (`Classes/Theme.cs`), palette centralisée, prise en charge du DPI par moniteur (`app.manifest`) pour un rendu net en haute résolution, mise en page plus robuste (moins de positionnement en pixels absolus).
- **Préférences persistées** : version, langue, applications et options avancées choisies sont mémorisées d'une exécution à l'autre.


Installateur WinForms .NET 8 pour Microsoft Office 2019, 2021 et 2024 LTSC, signe **by okitakoy**. L'application cible Windows 10/11 64 bits et demande les droits administrateur via UAC.

## Structure

- `Program.cs` : point d'entree, verification administrateur et relance UAC.
- `Forms/SplashForm.cs` : splash de trois secondes et lancement audio optionnel.
- `Forms/MainForm.cs` : choix de version, langue, applications et options avancees.
- `Forms/InstallProgressForm.cs` : execution modale et messages de progression.
- `Classes/XmlGenerator.cs` : generation UTF-8 sans BOM de `configuration.xml`.
- `Classes/ResourceExtractor.cs` : extraction de l'ODT embarque dans `%TEMP%\okitaInstaller`.
- `Classes/InstallerService.cs` : lancement de `setup.exe /configure`.
- `Classes/AudioManager.cs` : lecture en boucle optionnelle avec NAudio.
- `Classes/Theme.cs` : palette centralisée et composants visuels réutilisables (`RoundedButton`, `Card`).
- `app.manifest` : `requireAdministrator`.

## Integrer l'Office Deployment Tool

1. Telechargez l'Office Deployment Tool depuis la page officielle Microsoft : https://www.microsoft.com/download/details.aspx?id=49117
2. Executez l'archive ODT et acceptez son extraction.
3. Placez le fichier `setup.exe` obtenu dans `Resources/setup.exe`.
4. Le fichier est inclus comme ressource embarquee par le `.csproj`.
5. Ne distribuez pas un installeur Microsoft modifie hors des conditions de licence Microsoft.

Sans `Resources/setup.exe`, l'application se compile et s'ouvre, mais affiche une erreur claire au lancement de l'installation.

## Assets optionnels

Le depot contient des assets generes programmatiquement dans `Assets/` : `logo_okita.svg`, `logo_okita.png`, `icon.ico`, `splash.jpg`, `slide1.jpg`, `slide2.jpg`, `slide3.jpg` et `music.wav`. Le script reproductible est `Assets/generate_assets.py`.

Pour regenerer les assets :

```bash
python3 -m pip install --user Pillow
python3 Assets/generate_assets.py
```

Le WAV est une nappe instrumentale synthetique de 45 secondes, lisible en boucle. Pour une musique libre de droits plus riche, consultez [Pixabay Music](https://pixabay.com/music/) ou [Free Music Archive](https://freemusicarchive.org/), puis placez un fichier `music.mp3` dans `Assets/`. Les erreurs audio sont ignorees afin de ne pas bloquer l'application.

Les images du diaporama sont des JPG 1920x1080 personnalisables. Remplacez-les en conservant les noms `splash.jpg`, `slide1.jpg`, `slide2.jpg` et `slide3.jpg`, ou modifiez le script. Le logo peut etre modifie dans `logo_okita.svg`, puis regenere en PNG et ICO avec le meme script.

Les assets sont embarques dans l'executable lorsqu'ils existent. En leur absence, le splash utilise un logo dessine en code, le diaporama un fond bleu/violet genere en code et l'audio reste desactive.

Pour ajouter l'ODT, placez manuellement `setup.exe` dans `Resources/setup.exe`. Le fichier est ignore par Git et embarque uniquement au moment de la publication.

## Configuration XML

Le generateur produit l'edition volume, le canal LTSC, la langue choisie, les applications exclues, la fermeture forcee, la licence, l'activation et les mises a jour. Le fichier temporaire est genere dans `%TEMP%\okitaInstaller\configuration.xml` en UTF-8 sans BOM.

Les cles PID fournies dans le code correspondent aux exemples publics du cahier des charges. La licence et l'activation Office restent soumises aux droits de l'organisation et aux conditions Microsoft.

## Compiler

Prerequis : SDK .NET 8 ou plus recent, sur Windows pour executer l'interface.

```powershell
dotnet restore
dotnet build -c Release
```

Le projet est compilable depuis Linux avec `EnableWindowsTargeting=true`, mais une interface WinForms ne peut pas y etre executee.

## Publier un seul executable

```powershell
dotnet publish -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true
```

Le resultat est dans `bin/Release/net8.0-windows/win-x64/publish/okitaInstalleurOffice.exe`. Il contient les bibliotheques .NET ainsi que `setup.exe` si la ressource a ete fournie avant la publication.

Testez toujours l'executable publie sur une machine Windows de test. L'installation Office depend de la connectivite Microsoft et des politiques de licence de la machine.

## Notes d'execution

- L'application demande automatiquement l'elevation UAC.
- L'absence de reseau est remontee par le code de sortie d'ODT et affichee dans la fenetre de progression.
- La fermeture de la fenetre de progression interrompt uniquement l'attente locale; ODT peut deja etre en cours.