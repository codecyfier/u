using System.Diagnostics;
using OkitaInstalleurOffice.Classes;

namespace OkitaInstalleurOffice.Forms;

public sealed class InstallProgressForm : Form
{
    private readonly OfficeConfig config;
    private readonly AppSettings settings;
    private readonly Label status = new() { Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleCenter, ForeColor = Theme.TextPrimary, Font = Theme.HeadingFont };
    private readonly Label detail = new() { Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleCenter, ForeColor = Theme.TextSecondary, Font = Theme.BodyFont };
    private readonly Label elapsed = new() { Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleCenter, ForeColor = Theme.TextMuted, Font = Theme.SmallFont };
    private readonly ProgressBar bar = new() { Dock = DockStyle.Fill, Height = 14, Style = ProgressBarStyle.Continuous, Minimum = 0, Maximum = 100 };
    private readonly FlowLayoutPanel actions = new() { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft, WrapContents = false };
    private readonly RoundedButton close = new() { Text = "Annuler", Width = 150, Height = 42, Kind = ButtonKind.Danger };
    private readonly RoundedButton retry = new() { Text = "Réessayer", Width = 150, Height = 42, Visible = false, Kind = ButtonKind.Primary };
    private readonly RoundedButton viewLog = new() { Text = "Voir le journal", Width = 150, Height = 42, Visible = false, Kind = ButtonKind.Secondary };
    private readonly RoundedButton copyError = new() { Text = "Copier le détail", Width = 150, Height = 42, Visible = false, Kind = ButtonKind.Secondary };
    private readonly System.Windows.Forms.Timer clock = new() { Interval = 1000 };
    private readonly System.Windows.Forms.Timer smoothing = new() { Interval = 30 };
    private readonly AudioManager chimePlayer = new();
    private CancellationTokenSource cancellation = new();
    private DateTime startedAt;
    private bool running;
    private int displayedValue;
    private int targetValue;
    private string? lastErrorDetail;

    public InstallProgressForm(OfficeConfig config, AppSettings settings)
    {
        this.config = config;
        this.settings = settings;
        chimePlayer.SetMuted(settings.Muted);

        Text = "Installation Office - okitakoy";
        ClientSize = new Size(680, 400);
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        BackColor = Theme.Canvas;
        Font = Theme.BodyFont;

        var card = new Card { Header = null, Dock = DockStyle.Fill, SurfaceColor = Theme.Canvas };

        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 5, ColumnCount = 1 };
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 34));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 20));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 20));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 24));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 55));
        layout.Controls.Add(status, 0, 0);
        layout.Controls.Add(detail, 0, 1);
        layout.Controls.Add(elapsed, 0, 2);
        layout.Controls.Add(bar, 0, 3);

        foreach (var button in new[] { retry, close, copyError, viewLog })
            button.SurfaceColor = Theme.CardBackground;

        actions.Controls.AddRange([retry, close, copyError, viewLog]);
        layout.Controls.Add(actions, 0, 4);
        card.Controls.Add(layout);

        var outer = new Panel { Dock = DockStyle.Fill, BackColor = Theme.Canvas, Padding = new Padding(24) };
        outer.Controls.Add(card);
        Controls.Add(outer);

        close.Click += OnCloseClicked;
        retry.Click += async (_, _) => await RestartAsync();
        viewLog.Click += (_, _) => OpenLog();
        copyError.Click += (_, _) => CopyErrorToClipboard();
        clock.Tick += (_, _) => UpdateElapsed();
        smoothing.Tick += (_, _) => StepSmoothing();
        Shown += async (_, _) => await RunAsync();
        FormClosed += (_, _) => chimePlayer.Dispose();
    }

    private async Task RunAsync()
    {
        SetFailureControlsVisible(false);
        lastErrorDetail = null;
        SetCloseButtonState(running: true);
        try
        {
            startedAt = DateTime.UtcNow;
            running = true;
            displayedValue = 0;
            targetValue = 0;
            bar.Value = 0;
            clock.Start();
            smoothing.Start();
            var progress = new Progress<string>(UpdateProgress);
            await new InstallerService().InstallAsync(config, progress, cancellation.Token);
            clock.Stop();
            running = false;
            status.Text = "Terminé !";
            targetValue = 100;
            SetCloseButtonState(running: false, outcome: Outcome.Success);
            chimePlayer.PlayChime(success: true);
        }
        catch (OperationCanceledException)
        {
            clock.Stop();
            running = false;
            status.Text = "Installation annulée";
            detail.Text = "Le processus Office a été arrêté.";
            SetCloseButtonState(running: false, outcome: Outcome.Cancelled);
        }
        catch (Exception exception)
        {
            clock.Stop();
            running = false;
            status.Text = "Échec de l'installation";
            detail.Text = exception.Message;
            lastErrorDetail = $"{exception.Message}\n\nJournal complet : {Logger.FilePath}";
            SetCloseButtonState(running: false, outcome: Outcome.Failure);
            SetFailureControlsVisible(true);
            chimePlayer.PlayChime(success: false);
        }
    }

    private enum Outcome { Success, Cancelled, Failure }

    private void SetCloseButtonState(bool running, Outcome outcome = Outcome.Success)
    {
        if (running)
        {
            close.Text = "Annuler";
            close.Kind = ButtonKind.Danger;
            close.Enabled = true;
            return;
        }

        close.Text = "Fermer";
        close.Enabled = true;
        close.Kind = outcome == Outcome.Success ? ButtonKind.Primary : ButtonKind.Secondary;
    }

    private async Task RestartAsync()
    {
        cancellation.Dispose();
        cancellation = new CancellationTokenSource();
        await RunAsync();
    }

    private void SetFailureControlsVisible(bool visible)
    {
        retry.Visible = visible;
        viewLog.Visible = visible;
        copyError.Visible = visible;
    }

    private void OpenLog()
    {
        try
        {
            if (File.Exists(Logger.FilePath))
                Process.Start(new ProcessStartInfo { FileName = Logger.FilePath, UseShellExecute = true });
            else
                MessageBox.Show(this, "Aucun fichier journal n'a encore été créé pour cette session.", "Journal introuvable", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception exception)
        {
            MessageBox.Show(this, $"Impossible d'ouvrir le journal : {exception.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void CopyErrorToClipboard()
    {
        try
        {
            Clipboard.SetText(lastErrorDetail ?? detail.Text);
            detail.Text = "Détail copié dans le presse-papiers.";
        }
        catch (Exception exception)
        {
            MessageBox.Show(this, $"Impossible de copier dans le presse-papiers : {exception.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void UpdateProgress(string message)
    {
        var parts = message.Split('|', 3);
        if (parts.Length == 3 && int.TryParse(parts[0], out var value))
        {
            targetValue = Math.Clamp(value, 0, 100);
            status.Text = parts[1];
            detail.Text = parts[2];
        }
        else if (!string.IsNullOrWhiteSpace(message))
        {
            detail.Text = message;
        }
    }

    /// <summary>
    /// Anime la barre de progression vers sa cible par petits pas réguliers plutôt que par sauts
    /// brusques, pour une sensation de progression fluide et continue même quand ODT ne rapporte
    /// aucune valeur intermédiaire.
    /// </summary>
    private void StepSmoothing()
    {
        if (displayedValue == targetValue) return;
        displayedValue += displayedValue < targetValue ? 1 : -1;
        bar.Value = Math.Clamp(displayedValue, 0, 100);
    }

    private void UpdateElapsed()
    {
        var duration = DateTime.UtcNow - startedAt;
        elapsed.Text = $"Temps écoulé : {duration:mm\\:ss} · ODT travaille en arrière-plan, la progression est estimée.";
    }

    private void OnCloseClicked(object? sender, EventArgs e)
    {
        if (running && !cancellation.IsCancellationRequested)
        {
            close.Enabled = false;
            status.Text = "Annulation en cours...";
            detail.Text = "Arrêt du processus Office, veuillez patienter.";
            cancellation.Cancel();
            return;
        }
        Close();
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            cancellation.Cancel();
            cancellation.Dispose();
            clock.Dispose();
            smoothing.Dispose();
            chimePlayer.Dispose();
        }
        base.Dispose(disposing);
    }
}
