using OkitaInstalleurOffice.Classes;

namespace OkitaInstalleurOffice.Forms;

public sealed class SplashForm : Form
{
    private readonly System.Windows.Forms.Timer timer = new() { Interval = 50 };
    private readonly ProgressBar progress = new() { Style = ProgressBarStyle.Marquee, MarqueeAnimationSpeed = 25 };
    private readonly AudioManager audio = new();
    private readonly AppSettings settings = AppSettings.Load();
    private readonly RoundedButton muteButton = new() { Size = new Size(38, 38), Kind = ButtonKind.Ghost, Font = new Font("Segoe UI", 13), Location = new Point(550, 14) };
    private Image? background;
    private PictureBox? logo;
    private int elapsed;

    public SplashForm()
    {
        Text = "okitaInstalleur Office - by okitakoy";
        ClientSize = new Size(600, 400);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.None;
        BackColor = Color.FromArgb(10, 12, 16);
        DoubleBuffered = true;
        background = AssetLoader.LoadImage("splash.jpg");
        if (background is not null) { BackgroundImage = background; BackgroundImageLayout = ImageLayout.Stretch; }
        logo = new PictureBox { Image = AssetLoader.LoadImage("logo_okita.png") ?? CreateFallbackLogo(), SizeMode = PictureBoxSizeMode.Zoom, BackColor = Color.Transparent, Size = new Size(170, 170), Location = new Point(215, 62) };
        var title = new Label { Text = "okitaInstalleur Office", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleCenter, Font = new Font("Segoe UI", 24, FontStyle.Bold), ForeColor = Color.White, BackColor = Color.Transparent };
        var subtitle = new Label { Text = "Préparation de l'installation…", AutoSize = true, ForeColor = Color.FromArgb(200, 210, 225), Font = new Font("Segoe UI", 9.5f), BackColor = Color.Transparent, Location = new Point(232, 312) };
        var signature = new Label { Text = "by okitakoy", AutoSize = true, ForeColor = Color.FromArgb(155, 163, 175), Font = new Font("Segoe UI", 9), BackColor = Color.Transparent, Anchor = AnchorStyles.Bottom | AnchorStyles.Right, Location = new Point(500, 368) };
        progress.SetBounds(30, 342, 540, 4);

        muteButton.SurfaceColor = Color.FromArgb(20, 20, 26);
        UpdateMuteButtonGlyph();
        muteButton.Click += (_, _) =>
        {
            settings.Muted = !settings.Muted;
            audio.SetMuted(settings.Muted);
            settings.Save();
            UpdateMuteButtonGlyph();
        };

        var titleHost = new Panel { Location = new Point(0, 235), Size = new Size(600, 60), BackColor = Color.Transparent };
        titleHost.Controls.Add(title);

        Controls.Add(titleHost);
        Controls.Add(logo);
        Controls.Add(subtitle);
        Controls.Add(signature);
        Controls.Add(progress);
        Controls.Add(muteButton);
        Shown += (_, _) =>
        {
            audio.PlayLoop("music.mp3", settings.Volume, settings.Muted);
            _ = Task.Run(() =>
            {
                try { new ResourceExtractor().ExtractSetup(); }
                catch (Exception exception) { Logger.Warn($"Pré-extraction de setup.exe échouée (non bloquant) : {exception.Message}"); }
            });
            timer.Start();
        };
        timer.Tick += OnTick;
        FormClosed += (_, _) => { audio.Dispose(); background?.Dispose(); logo?.Image?.Dispose(); };
    }

    private void UpdateMuteButtonGlyph() => muteButton.Text = settings.Muted ? "🔇" : "🔊";

    private void OnTick(object? sender, EventArgs e)
    {
        elapsed += timer.Interval;
        if (elapsed < 3000) return;
        timer.Stop();
        audio.FadeOut(400);
        Hide();
        using var main = new MainForm(settings);
        main.ShowDialog(this);
        Close();
    }

    private static Image CreateFallbackLogo()
    {
        var image = new Bitmap(256, 256);
        using var graphics = Graphics.FromImage(image);
        graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        var colors = new[] { Color.FromArgb(0, 150, 240), Color.FromArgb(90, 110, 235), Color.FromArgb(125, 55, 165), Color.FromArgb(0, 190, 190) };
        var positions = new[] { new Point(0, 0), new Point(136, 0), new Point(0, 136), new Point(136, 136) };
        for (var index = 0; index < positions.Length; index++)
        {
            using var brush = new SolidBrush(colors[index]);
            using var path = Theme.RoundedRect(new RectangleF(positions[index], new SizeF(120, 120)), 22f);
            graphics.FillPath(brush, path);
        }
        return image;
    }
}
