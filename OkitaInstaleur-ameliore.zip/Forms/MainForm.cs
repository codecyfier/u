using System.Drawing.Drawing2D;
using OkitaInstalleurOffice.Classes;

namespace OkitaInstalleurOffice.Forms;

public sealed class MainForm : Form
{
    private readonly List<Image> slides = new();
    private readonly System.Windows.Forms.Timer slideshow = new() { Interval = 6000 };
    private int slideIndex;
    private readonly OfficeConfig config = new();
    private readonly AppSettings settings;
    private readonly AudioManager audio = new();
    private readonly Dictionary<string, CheckBox> apps = new(StringComparer.OrdinalIgnoreCase);
    private readonly ComboBox version = new();
    private readonly ComboBox language = new();
    private readonly CheckBox eula = new() { Text = "Accepter automatiquement la licence EULA", AutoSize = true };
    private readonly CheckBox shutdown = new() { Text = "Forcer la fermeture des applications Office", AutoSize = true };
    private readonly CheckBox updates = new() { Text = "Activer les mises à jour automatiques", AutoSize = true };
    private readonly CheckBox x64 = new() { Text = "Forcer l'architecture 64 bits", AutoSize = true };
    private readonly RoundedButton install = new() { Text = "LANCER L'INSTALLATION", Kind = ButtonKind.Primary, Height = 52, Dock = DockStyle.Fill };
    private readonly RoundedButton muteButton = new() { Size = new Size(40, 40), Kind = ButtonKind.Ghost, Font = new Font("Segoe UI", 13) };
    private readonly TrackBar volumeSlider = new() { Minimum = 0, Maximum = 100, Width = 110, TickStyle = TickStyle.None };
    private readonly HeroBanner hero = new() { Dock = DockStyle.Top, Height = 168 };
    private readonly Card banner = new() { Dock = DockStyle.Top, Height = 0, Visible = false, Margin = new Padding(0) };
    private readonly Label bannerText = new() { Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(18, 0, 18, 0), Font = Theme.BodyFont, AutoEllipsis = true };
    private bool blockedByPreflight;

    public MainForm(AppSettings settings)
    {
        this.settings = settings;
        Text = "okitaInstalleur Office - by okitakoy";
        WindowState = FormWindowState.Maximized;
        MinimumSize = new Size(980, 720);
        BackColor = Theme.Canvas;
        ForeColor = Theme.TextPrimary;
        Font = Theme.BodyFont;
        LoadSlides();
        RestoreSettings();
        BuildUi();
        _ = RunPreflightChecksAsync();
        audio.PlayLoop("music.mp3", settings.Volume, settings.Muted);
        slideshow.Tick += (_, _) => ShowNextSlide();
        slideshow.Start();
        FormClosed += (_, _) =>
        {
            slideshow.Stop();
            audio.Dispose();
            foreach (var slide in slides) slide.Dispose();
        };
    }

    private void RestoreSettings()
    {
        eula.Checked = settings.AutoAcceptEula;
        shutdown.Checked = settings.ForceShutdown;
        updates.Checked = settings.EnableUpdates;
        x64.Checked = settings.Architecture64;
    }

    private void LoadSlides()
    {
        foreach (var fileName in new[] { "splash.jpg", "slide1.jpg", "slide2.jpg", "slide3.jpg" })
        {
            var image = AssetLoader.LoadImage(fileName);
            if (image is not null) slides.Add(image);
        }
        ShowNextSlide();
    }

    private void ShowNextSlide()
    {
        hero.BackgroundPhoto = slides.Count == 0 ? null : slides[slideIndex++ % slides.Count];
    }

    private void BuildUi()
    {
        var outer = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, BackColor = Theme.Canvas };
        outer.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        outer.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        outer.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        BuildHero();
        outer.Controls.Add(hero, 0, 0);

        BuildBanner();
        outer.Controls.Add(banner, 0, 1);

        var body = new Panel { Dock = DockStyle.Fill, AutoScroll = true, BackColor = Theme.Canvas };
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            Padding = new Padding(48, 26, 48, 26),
            ColumnCount = 2,
            RowCount = 4,
            BackColor = Theme.Canvas,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink
        };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 124));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 196));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 188));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 78));

        root.Controls.Add(CreateSelection("Version d'Office", version, ["Office 2024 (LTSC) - Recommandé", "Office 2021 (LTSC)", "Office 2019"]), 0, 0);
        root.Controls.Add(CreateSelection("Langue", language, ["Français (fr-fr)", "Anglais (en-us)", "Espagnol (es-es)", "Arabe (ar-sa)"]), 1, 0);

        var appsCard = CreateApps();
        root.Controls.Add(appsCard, 0, 1);
        root.SetColumnSpan(appsCard, 2);

        var optionsCard = CreateOptions();
        root.Controls.Add(optionsCard, 0, 2);
        root.SetColumnSpan(optionsCard, 2);

        var actionRow = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 1, Margin = new Padding(0, 10, 0, 0) };
        install.SurfaceColor = Theme.Canvas;
        install.Click += StartInstall;
        actionRow.Controls.Add(install, 0, 0);
        root.Controls.Add(actionRow, 0, 3);
        root.SetColumnSpan(actionRow, 2);

        body.Controls.Add(root);
        outer.Controls.Add(body, 0, 2);

        var signature = new Label { Text = "by okitakoy", Dock = DockStyle.Bottom, TextAlign = ContentAlignment.MiddleRight, Padding = new Padding(0, 0, 20, 6), ForeColor = Theme.TextMuted, Font = Theme.SmallFont, Height = 26, BackColor = Theme.Canvas };

        Controls.Add(outer);
        Controls.Add(signature);

        version.SelectedIndex = Math.Clamp(settings.VersionIndex, 0, version.Items.Count - 1);
        language.SelectedIndex = Math.Clamp(settings.LanguageIndex, 0, language.Items.Count - 1);
        foreach (var (name, check) in apps)
            check.Checked = !settings.UncheckedApps.Contains(name, StringComparer.OrdinalIgnoreCase);
    }

    private void BuildHero()
    {
        var title = new Label
        {
            Text = "okitaInstalleur Office",
            AutoSize = false,
            Dock = DockStyle.Fill,
            Font = Theme.TitleFont,
            ForeColor = Color.White,
            BackColor = Color.Transparent,
            TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(28, 0, 0, 4)
        };
        var subtitle = new Label
        {
            Text = "Installation personnalisée de Microsoft Office",
            AutoSize = false,
            Dock = DockStyle.Fill,
            Font = Theme.SubtitleFont,
            ForeColor = Color.FromArgb(225, 232, 240),
            BackColor = Color.Transparent,
            TextAlign = ContentAlignment.TopLeft,
            Padding = new Padding(28, 0, 0, 0)
        };

        var textStack = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, BackColor = Color.Transparent };
        textStack.RowStyles.Add(new RowStyle(SizeType.Percent, 60));
        textStack.RowStyles.Add(new RowStyle(SizeType.Percent, 40));
        textStack.Controls.Add(title, 0, 0);
        textStack.Controls.Add(subtitle, 0, 1);

        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, BackColor = Color.Transparent };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 190));
        layout.Controls.Add(textStack, 0, 0);
        layout.Controls.Add(BuildSoundControls(), 1, 0);

        hero.Controls.Add(layout);
    }

    private void BuildBanner()
    {
        banner.Header = null;
        banner.BorderColor = Theme.WarningBorder;
        banner.BackColor = Theme.WarningBackground;
        banner.Padding = new Padding(0);
        bannerText.ForeColor = Theme.WarningText;
        banner.Controls.Add(bannerText);
    }

    private Control BuildSoundControls()
    {
        muteButton.SurfaceColor = Color.FromArgb(22, 44, 76);
        UpdateMuteGlyph();
        muteButton.Click += (_, _) =>
        {
            settings.Muted = !settings.Muted;
            audio.SetMuted(settings.Muted);
            settings.Save();
            UpdateMuteGlyph();
        };

        volumeSlider.Value = (int)(settings.Volume * 100);
        volumeSlider.Margin = new Padding(8, 26, 4, 0);
        volumeSlider.Scroll += (_, _) =>
        {
            settings.Volume = volumeSlider.Value / 100f;
            audio.SetVolume(settings.Volume);
            settings.Save();
        };

        var panel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft, WrapContents = false, Padding = new Padding(0, 24, 12, 0), BackColor = Color.Transparent };
        panel.Controls.Add(muteButton);
        panel.Controls.Add(volumeSlider);
        return panel;
    }

    private void UpdateMuteGlyph() => muteButton.Text = settings.Muted ? "🔇" : "🔊";

    private async Task RunPreflightChecksAsync()
    {
        var results = await PreflightChecks.RunAsync();
        var blocking = results.Where(r => r.Severity == PreflightSeverity.Blocking).ToList();
        var warnings = results.Where(r => r.Severity == PreflightSeverity.Warning).ToList();

        if (IsDisposed) return;

        if (blocking.Count > 0)
        {
            ShowBanner(isError: true, string.Join("  •  ", blocking.Select(b => b.Message)));
            blockedByPreflight = true;
            install.Enabled = false;
        }
        else if (warnings.Count > 0)
        {
            ShowBanner(isError: false, string.Join("  •  ", warnings.Select(w => w.Message)));
        }
    }

    private void ShowBanner(bool isError, string message)
    {
        if (InvokeRequired) { BeginInvoke(new Action(() => ShowBanner(isError, message))); return; }
        banner.BackColor = isError ? Theme.DangerBackground : Theme.WarningBackground;
        banner.BorderColor = isError ? Theme.DangerBorder : Theme.WarningBorder;
        bannerText.ForeColor = isError ? Theme.DangerText : Theme.WarningText;
        bannerText.Text = message;
        banner.Height = 46;
        banner.Visible = true;
    }

    private Card CreateSelection(string title, ComboBox box, string[] values)
    {
        Theme.StyleComboBox(box);
        box.Dock = DockStyle.Fill;
        box.DropDownStyle = ComboBoxStyle.DropDownList;
        box.Items.AddRange(values);
        box.Margin = new Padding(0, 6, 0, 0);
        box.SelectedIndexChanged += (_, _) =>
        {
            if (box == version)
                config.Version = version.SelectedIndex switch { 1 => "ProPlus2021Volume", 2 => "ProPlus2019Volume", _ => "ProPlus2024Volume" };
            else
                config.Language = language.SelectedIndex switch { 1 => "en-us", 2 => "es-es", 3 => "ar-sa", _ => "fr-fr" };
        };

        var card = new Card { Header = title, Dock = DockStyle.Fill, SurfaceColor = Theme.Canvas };
        card.Margin = title == "Version d'Office" ? new Padding(0, 0, 12, 16) : new Padding(12, 0, 0, 16);
        var host = new Panel { Dock = DockStyle.Fill };
        host.Controls.Add(box);
        card.Controls.Add(host);
        return card;
    }

    private Card CreateApps()
    {
        var card = new Card { Header = "Applications à installer", Dock = DockStyle.Fill, Margin = new Padding(0, 0, 0, 16), SurfaceColor = Theme.Canvas };
        var panel = new FlowLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(0), AutoScroll = true, BackColor = Color.Transparent };
        foreach (var name in new[] { "Word", "Excel", "PowerPoint", "Outlook", "Access", "Publisher", "OneNote", "Teams", "Skype Entreprise (Lync)" })
        {
            var check = new CheckBox { Text = name, Checked = name != "Skype Entreprise (Lync)", AutoSize = true, Margin = new Padding(0, 4, 28, 12) };
            Theme.StyleCheckBox(check);
            apps[name] = check;
            panel.Controls.Add(check);
        }
        card.Controls.Add(panel);
        return card;
    }

    private Card CreateOptions()
    {
        var card = new Card { Header = "Options avancées", Dock = DockStyle.Fill, Margin = new Padding(0, 0, 0, 16), SurfaceColor = Theme.Canvas };
        var panel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, Padding = new Padding(0), AutoScroll = true, BackColor = Color.Transparent };
        foreach (var check in new[] { eula, shutdown, updates, x64 })
        {
            check.Margin = new Padding(0, 4, 0, 10);
            Theme.StyleCheckBox(check);
        }
        panel.Controls.AddRange([eula, shutdown, updates, x64]);
        card.Controls.Add(panel);
        return card;
    }

    private async void StartInstall(object? sender, EventArgs e)
    {
        config.ExcludedApps = apps.Where(pair => !pair.Value.Checked).Select(pair => pair.Key.Contains("Skype", StringComparison.Ordinal) ? "Lync" : pair.Key).ToList();
        config.AutoAcceptEULA = eula.Checked;
        config.ForceShutdown = shutdown.Checked;
        config.EnableUpdates = updates.Checked;
        config.Architecture = x64.Checked ? 64 : 32;

        SaveCurrentSelectionToSettings();

        install.Enabled = false;
        try
        {
            using var progress = new InstallProgressForm(config, settings);
            progress.ShowDialog(this);
        }
        finally
        {
            install.Enabled = !blockedByPreflight;
        }
    }

    private void SaveCurrentSelectionToSettings()
    {
        settings.VersionIndex = version.SelectedIndex;
        settings.LanguageIndex = language.SelectedIndex;
        settings.UncheckedApps = apps.Where(pair => !pair.Value.Checked).Select(pair => pair.Key).ToList();
        settings.AutoAcceptEula = eula.Checked;
        settings.ForceShutdown = shutdown.Checked;
        settings.EnableUpdates = updates.Checked;
        settings.Architecture64 = x64.Checked;
        settings.Save();
    }

    /// <summary>
    /// Bandeau supérieur : photo de fond (diaporama existant) recouverte d'un dégradé sombre
    /// pour garantir la lisibilité du texte blanc, façon bannière "hero" Fluent/Apple. Le reste
    /// de la fenêtre reste une toile claire et neutre : la photo ne recouvre plus tout l'écran.
    /// </summary>
    private sealed class HeroBanner : Panel
    {
        private Image? backgroundPhoto;

        public Image? BackgroundPhoto
        {
            get => backgroundPhoto;
            set { backgroundPhoto = value; Invalidate(); }
        }

        public HeroBanner()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Color.FromArgb(10, 35, 70);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var graphics = e.Graphics;
            var bounds = ClientRectangle;
            if (bounds.Width <= 0 || bounds.Height <= 0) return;

            if (backgroundPhoto is not null)
                graphics.DrawImage(backgroundPhoto, bounds);
            else
            {
                using var fallback = new LinearGradientBrush(bounds, Color.FromArgb(8, 40, 85), Color.FromArgb(35, 15, 80), 25f);
                graphics.FillRectangle(fallback, bounds);
            }

            using var overlay = new LinearGradientBrush(bounds, Color.FromArgb(215, 8, 20, 40), Color.FromArgb(150, 8, 20, 40), 0f);
            graphics.FillRectangle(overlay, bounds);

            base.OnPaint(e);
        }
    }
}
