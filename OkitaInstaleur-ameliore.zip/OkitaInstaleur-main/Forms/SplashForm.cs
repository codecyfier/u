using OkitaInstalleurOffice.Classes;

namespace OkitaInstalleurOffice.Forms;

public sealed class SplashForm : Form
{
    private readonly System.Windows.Forms.Timer timer = new() { Interval = 50 };
    private readonly ProgressBar progress = new() { Style = ProgressBarStyle.Marquee, MarqueeAnimationSpeed = 25 };
    private readonly AudioManager audio = new();
    private readonly AppSettings settings = AppSettings.Load();
    private readonly Button muteButton = new() { Size = new Size(36, 36), Location = new Point(552, 12), Font = new Font("Segoe UI", 12) };
    private Image? background;
    private PictureBox? logo;
    private int elapsed;

    public SplashForm()
    {
        Text = "okitaInstalleur Office - by okitakoy";
        ClientSize = new Size(600, 400);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.None;
        BackColor = Color.FromArgb(10, 12, 16);
        DoubleBuffered = true;
        background = AssetLoader.LoadImage("splash.jpg");
        if (background is not null) { BackgroundImage = background; BackgroundImageLayout = ImageLayout.Stretch; }
        logo = new PictureBox { Image = AssetLoader.LoadImage("logo_okita.png") ?? CreateFallbackLogo(), SizeMode = PictureBoxSizeMode.Zoom, BackColor = Color.Transparent, Size = new Size(170, 170), Location = new Point(215, 65) };
        var title = new Label { Text = "okitaInstalleur Office", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleCenter, Font = new Font("Segoe UI", 25, FontStyle.Bold), ForeColor = Color.White };
        var signature = new Label { Text = "by okitakoy", AutoSize = true, ForeColor = Color.FromArgb(155, 163, 175), Font = new Font("Segoe UI", 9), Anchor = AnchorStyles.Bottom | AnchorStyles.Right, Location = new Point(500, 365) };
        progress.SetBounds(30, 340, 540, 5);

        Theme.StyleGhostButton(muteButton);
        UpdateMuteButtonGlyph();
        muteButton.Click += (_, _) =>
        {
            settings.Muted = !settings.Muted;
            audio.SetMuted(settings.Muted);
            settings.Save();
            UpdateMuteButtonGlyph();
        };

        Controls.Add(title);
        Controls.Add(logo);
        Controls.Add(signature);
        Controls.Add(progress);
        Controls.Add(muteButton);
        Shown += (_, _) =>
        {
            audio.PlayLoop("music.mp3", settings.Volume, settings.Muted);
            _ = Task.Run(() =>
            {
                try { new ResourceExtractor().ExtractSetup(); }
                catch (Exception exception) { Logger.Warn($"Pré-extraction de setup.exe échouée (non bloquant) : {exception.Message}"); }
            });
            timer.Start();
        };
        timer.Tick += OnTick;
        FormClosed += (_, _) => { audio.Dispose(); background?.Dispose(); logo?.Image?.Dispose(); };
    }

    private void UpdateMuteButtonGlyph() => muteButton.Text = settings.Muted ? "🔇" : "🔊";

    private void OnTick(object? sender, EventArgs e)
    {
        elapsed += timer.Interval;
        if (elapsed < 3000) return;
        timer.Stop();
        audio.FadeOut(400);
        Hide();
        using var main = new MainForm(settings);
        main.ShowDialog(this);
        Close();
    }

    private static Image CreateFallbackLogo()
    {
        var image = new Bitmap(256, 256);
        using var graphics = Graphics.FromImage(image);
        var colors = new[] { Color.FromArgb(0, 150, 240), Color.FromArgb(90, 110, 235), Color.FromArgb(125, 55, 165), Color.FromArgb(0, 190, 190) };
        var positions = new[] { new Point(0, 0), new Point(136, 0), new Point(0, 136), new Point(136, 136) };
        for (var index = 0; index < positions.Length; index++)
        {
            using var brush = new SolidBrush(colors[index]);
            graphics.FillRoundedRectangle(brush, new Rectangle(positions[index], new Size(120, 120)), 3);
        }
        return image;
    }
}

internal static class GraphicsExtensions
{
    public static void FillRoundedRectangle(this Graphics graphics, Brush brush, Rectangle bounds, int radius)
    {
        using var path = new System.Drawing.Drawing2D.GraphicsPath();
        var diameter = radius * 2;
        path.AddArc(bounds.X, bounds.Y, diameter, diameter, 180, 90);
        path.AddArc(bounds.Right - diameter, bounds.Y, diameter, diameter, 270, 90);
        path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(bounds.X, bounds.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();
        graphics.FillPath(brush, path);
    }
}
