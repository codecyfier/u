using OkitaInstalleurOffice.Classes;

namespace OkitaInstalleurOffice.Forms;

public sealed class MainForm : Form
{
    private readonly List<Image> slides = new();
    private readonly System.Windows.Forms.Timer slideshow = new() { Interval = 5000 };
    private Image? fallbackBackground;
    private int slideIndex;
    private readonly OfficeConfig config = new();
    private readonly AppSettings settings;
    private readonly AudioManager audio = new();
    private readonly Dictionary<string, CheckBox> apps = new(StringComparer.OrdinalIgnoreCase);
    private readonly ComboBox version = new();
    private readonly ComboBox language = new();
    private readonly CheckBox eula = new() { Text = "Accepter automatiquement la licence EULA", AutoSize = true };
    private readonly CheckBox shutdown = new() { Text = "Forcer la fermeture des applications Office", AutoSize = true };
    private readonly CheckBox updates = new() { Text = "Activer les mises à jour automatiques", AutoSize = true };
    private readonly CheckBox x64 = new() { Text = "Forcer l'architecture 64 bits", AutoSize = true };
    private readonly Button install = new() { Text = "LANCER L'INSTALLATION", Dock = DockStyle.Fill, Font = new Font("Segoe UI", 13, FontStyle.Bold), Margin = new Padding(260, 12, 260, 12) };
    private readonly Button muteButton = new() { Size = new Size(38, 38), Font = new Font("Segoe UI", 13) };
    private readonly TrackBar volumeSlider = new() { Minimum = 0, Maximum = 100, Width = 110, TickStyle = TickStyle.None };
    private readonly Panel banner = new() { Dock = DockStyle.Top, Height = 0, Visible = false };
    private readonly Label bannerText = new() { Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(16, 0, 16, 0), Font = Theme.BodyFont };
    private bool blockedByPreflight;

    public MainForm(AppSettings settings)
    {
        this.settings = settings;
        Text = "okitaInstalleur Office - by okitakoy";
        WindowState = FormWindowState.Maximized;
        MinimumSize = new Size(900, 700);
        BackColor = Theme.Background;
        ForeColor = Theme.TextPrimary;
        LoadSlides();
        RestoreSettings();
        BuildUi();
        _ = RunPreflightChecksAsync();
        audio.PlayLoop("music.mp3", settings.Volume, settings.Muted);
        slideshow.Tick += (_, _) => ShowNextSlide();
        slideshow.Start();
        FormClosed += (_, _) =>
        {
            slideshow.Stop();
            audio.Dispose();
            foreach (var slide in slides) slide.Dispose();
            fallbackBackground?.Dispose();
        };
    }

    private void RestoreSettings()
    {
        eula.Checked = settings.AutoAcceptEula;
        shutdown.Checked = settings.ForceShutdown;
        updates.Checked = settings.EnableUpdates;
        x64.Checked = settings.Architecture64;
    }

    private void LoadSlides()
    {
        foreach (var fileName in new[] { "splash.jpg", "slide1.jpg", "slide2.jpg", "slide3.jpg" })
        {
            var image = AssetLoader.LoadImage(fileName);
            if (image is not null) slides.Add(image);
        }
        if (slides.Count == 0) fallbackBackground = CreateFallbackBackground();
        ShowNextSlide();
    }

    private void ShowNextSlide()
    {
        if (slides.Count == 0) { BackgroundImage = fallbackBackground; return; }
        BackgroundImage = slides[slideIndex++ % slides.Count];
        BackgroundImageLayout = ImageLayout.Stretch;
    }

    private Image CreateFallbackBackground()
    {
        var image = new Bitmap(1200, 800);
        using var graphics = Graphics.FromImage(image);
        var bounds = new Rectangle(0, 0, image.Width, image.Height);
        using var brush = new System.Drawing.Drawing2D.LinearGradientBrush(bounds, Color.FromArgb(8, 35, 75), Color.FromArgb(45, 12, 70), 35f);
        graphics.FillRectangle(brush, bounds);
        return image;
    }

    private void BuildUi()
    {
        var outer = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2 };
        outer.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        outer.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        BuildBanner();
        outer.Controls.Add(banner, 0, 0);

        var root = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(55, 25, 55, 25), ColumnCount = 2, RowCount = 5, BackColor = Color.Transparent };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50)); root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 95)); root.RowStyles.Add(new RowStyle(SizeType.Absolute, 110)); root.RowStyles.Add(new RowStyle(SizeType.Absolute, 185)); root.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); root.RowStyles.Add(new RowStyle(SizeType.Absolute, 80));

        var headerRow = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
        headerRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        headerRow.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 180));
        var heading = new Label { Text = "okitaInstalleur Office\nInstallation personnalisée de Microsoft Office", Dock = DockStyle.Fill, Font = Theme.TitleFont, ForeColor = Color.White, TextAlign = ContentAlignment.MiddleCenter };
        headerRow.Controls.Add(heading, 0, 0);
        headerRow.Controls.Add(BuildSoundControls(), 1, 0);
        root.Controls.Add(headerRow, 0, 0); root.SetColumnSpan(headerRow, 2);
        root.Controls.Add(CreateSelection("Version d'Office", version, ["Office 2024 (LTSC) - Recommandé", "Office 2021 (LTSC)", "Office 2019"]), 0, 1);
        root.Controls.Add(CreateSelection("Langue", language, ["Français (fr-fr)", "Anglais (en-us)", "Espagnol (es-es)", "Arabe (ar-sa)"]), 1, 1);
        root.Controls.Add(CreateApps(), 0, 2); root.SetColumnSpan(root.GetControlFromPosition(0, 2)!, 2);
        root.Controls.Add(CreateOptions(), 0, 3); root.SetColumnSpan(root.GetControlFromPosition(0, 3)!, 2);

        Theme.StyleAccentButton(install);
        install.FlatAppearance.BorderSize = 0; install.Click += StartInstall;
        root.Controls.Add(install, 0, 4); root.SetColumnSpan(install, 2);

        outer.Controls.Add(root, 0, 1);

        var signature = new Label { Text = "by okitakoy", Dock = DockStyle.Bottom, TextAlign = ContentAlignment.MiddleRight, Padding = new Padding(0, 0, 16, 4), ForeColor = Theme.TextMuted, Height = 24 };
        Controls.Add(outer);
        Controls.Add(signature);

        version.SelectedIndex = Math.Clamp(settings.VersionIndex, 0, version.Items.Count - 1);
        language.SelectedIndex = Math.Clamp(settings.LanguageIndex, 0, language.Items.Count - 1);
        foreach (var (name, check) in apps)
            check.Checked = !settings.UncheckedApps.Contains(name, StringComparer.OrdinalIgnoreCase);
    }

    private void BuildBanner()
    {
        banner.BackColor = Theme.Warning;
        bannerText.ForeColor = Color.FromArgb(35, 28, 5);
        banner.Controls.Add(bannerText);
    }

    private Control BuildSoundControls()
    {
        Theme.StyleGhostButton(muteButton);
        UpdateMuteGlyph();
        muteButton.Click += (_, _) =>
        {
            settings.Muted = !settings.Muted;
            audio.SetMuted(settings.Muted);
            settings.Save();
            UpdateMuteGlyph();
        };

        volumeSlider.Value = (int)(settings.Volume * 100);
        volumeSlider.Margin = new Padding(8, 20, 4, 0);
        volumeSlider.Scroll += (_, _) =>
        {
            settings.Volume = volumeSlider.Value / 100f;
            audio.SetVolume(settings.Volume);
            settings.Save();
        };

        var panel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft, WrapContents = false, Padding = new Padding(0, 18, 8, 0) };
        panel.Controls.Add(muteButton);
        panel.Controls.Add(volumeSlider);
        return panel;
    }

    private void UpdateMuteGlyph() => muteButton.Text = settings.Muted ? "🔇" : "🔊";

    private async Task RunPreflightChecksAsync()
    {
        var results = await PreflightChecks.RunAsync();
        var blocking = results.Where(r => r.Severity == PreflightSeverity.Blocking).ToList();
        var warnings = results.Where(r => r.Severity == PreflightSeverity.Warning).ToList();

        if (IsDisposed) return;

        if (blocking.Count > 0)
        {
            ShowBanner(Theme.Danger, string.Join("  •  ", blocking.Select(b => b.Message)));
            blockedByPreflight = true;
            install.Enabled = false;
        }
        else if (warnings.Count > 0)
        {
            ShowBanner(Theme.Warning, string.Join("  •  ", warnings.Select(w => w.Message)));
        }
    }

    private void ShowBanner(Color color, string message)
    {
        if (InvokeRequired) { BeginInvoke(new Action(() => ShowBanner(color, message))); return; }
        banner.BackColor = color;
        bannerText.ForeColor = color == Theme.Danger ? Color.White : Color.FromArgb(35, 28, 5);
        bannerText.Text = message;
        banner.Height = 34;
        banner.Visible = true;
    }

    private GroupBox CreateSelection(string title, ComboBox box, string[] values)
    {
        box.Dock = DockStyle.Fill; box.DropDownStyle = ComboBoxStyle.DropDownList; box.Items.AddRange(values); box.Margin = new Padding(12); box.BackColor = Theme.PanelBackground; box.ForeColor = Color.White;
        box.SelectedIndexChanged += (_, _) => { if (box == version) config.Version = version.SelectedIndex switch { 1 => "ProPlus2021Volume", 2 => "ProPlus2019Volume", _ => "ProPlus2024Volume" }; else config.Language = language.SelectedIndex switch { 1 => "en-us", 2 => "es-es", 3 => "ar-sa", _ => "fr-fr" }; };
        var group = new GroupBox { Text = title, Dock = DockStyle.Fill, ForeColor = Color.Gainsboro, Padding = new Padding(10) }; group.Controls.Add(box); return group;
    }

    private Control CreateApps()
    {
        var group = new GroupBox { Text = "Applications à installer", Dock = DockStyle.Fill, ForeColor = Color.Gainsboro };
        var panel = new FlowLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(12), AutoScroll = true };
        foreach (var name in new[] { "Word", "Excel", "PowerPoint", "Outlook", "Access", "Publisher", "OneNote", "Teams", "Skype Entreprise (Lync)" })
        { var check = new CheckBox { Text = name, Checked = name != "Skype Entreprise (Lync)", AutoSize = true, ForeColor = Color.White, Margin = new Padding(12) }; apps[name] = check; panel.Controls.Add(check); }
        group.Controls.Add(panel); return group;
    }

    private Control CreateOptions()
    {
        var group = new GroupBox { Text = "Options avancées", Dock = DockStyle.Fill, ForeColor = Color.Gainsboro };
        var panel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, Padding = new Padding(12) };
        panel.Controls.AddRange([eula, shutdown, updates, x64]); group.Controls.Add(panel); return group;
    }

    private async void StartInstall(object? sender, EventArgs e)
    {
        config.ExcludedApps = apps.Where(pair => !pair.Value.Checked).Select(pair => pair.Key.Contains("Skype", StringComparison.Ordinal) ? "Lync" : pair.Key).ToList();
        config.AutoAcceptEULA = eula.Checked; config.ForceShutdown = shutdown.Checked; config.EnableUpdates = updates.Checked; config.Architecture = x64.Checked ? 64 : 32;

        SaveCurrentSelectionToSettings();

        install.Enabled = false;
        try
        {
            using var progress = new InstallProgressForm(config, settings);
            progress.ShowDialog(this);
        }
        finally
        {
            install.Enabled = !blockedByPreflight;
        }
    }

    private void SaveCurrentSelectionToSettings()
    {
        settings.VersionIndex = version.SelectedIndex;
        settings.LanguageIndex = language.SelectedIndex;
        settings.UncheckedApps = apps.Where(pair => !pair.Value.Checked).Select(pair => pair.Key).ToList();
        settings.AutoAcceptEula = eula.Checked;
        settings.ForceShutdown = shutdown.Checked;
        settings.EnableUpdates = updates.Checked;
        settings.Architecture64 = x64.Checked;
        settings.Save();
    }
}
