namespace OkitaInstalleurOffice.Classes;

/// <summary>
/// Palette centralisée et helpers de style, pour que tous les écrans partagent la même
/// identité visuelle et que les boutons réagissent au survol/au clic.
/// </summary>
public static class Theme
{
    public static readonly Color Background = Color.FromArgb(12, 15, 20);
    public static readonly Color PanelBackground = Color.FromArgb(22, 26, 34);
    public static readonly Color Accent = Color.FromArgb(0, 145, 210);
    public static readonly Color AccentHover = Color.FromArgb(20, 170, 235);
    public static readonly Color AccentPressed = Color.FromArgb(0, 115, 175);
    public static readonly Color Success = Color.FromArgb(46, 175, 110);
    public static readonly Color Danger = Color.FromArgb(210, 75, 75);
    public static readonly Color Warning = Color.FromArgb(225, 170, 40);
    public static readonly Color TextPrimary = Color.White;
    public static readonly Color TextSecondary = Color.FromArgb(180, 190, 205);
    public static readonly Color TextMuted = Color.Gray;

    public static readonly Font TitleFont = new("Segoe UI", 21, FontStyle.Bold);
    public static readonly Font HeadingFont = new("Segoe UI", 13, FontStyle.Bold);
    public static readonly Font BodyFont = new("Segoe UI", 9.5f);

    /// <summary>Applique un style bouton "accent" plein avec un vrai retour visuel au survol/clic.</summary>
    public static void StyleAccentButton(Button button, Color? baseColor = null, Color? hoverColor = null, Color? pressedColor = null)
    {
        var normal = baseColor ?? Accent;
        var hover = hoverColor ?? AccentHover;
        var pressed = pressedColor ?? AccentPressed;

        button.FlatStyle = FlatStyle.Flat;
        button.FlatAppearance.BorderSize = 0;
        button.BackColor = normal;
        button.ForeColor = TextPrimary;
        button.Cursor = Cursors.Hand;

        button.MouseEnter += (_, _) => { if (button.Enabled) button.BackColor = hover; };
        button.MouseLeave += (_, _) => { if (button.Enabled) button.BackColor = normal; };
        button.MouseDown += (_, _) => { if (button.Enabled) button.BackColor = pressed; };
        button.MouseUp += (_, _) => { if (button.Enabled) button.BackColor = hover; };
        button.EnabledChanged += (_, _) => button.BackColor = button.Enabled ? normal : Color.FromArgb(60, 65, 75);
    }

    /// <summary>Style discret pour un bouton secondaire (icône son, actions annexes).</summary>
    public static void StyleGhostButton(Button button)
    {
        button.FlatStyle = FlatStyle.Flat;
        button.FlatAppearance.BorderSize = 1;
        button.FlatAppearance.BorderColor = Color.FromArgb(70, 78, 92);
        button.BackColor = PanelBackground;
        button.ForeColor = TextPrimary;
        button.Cursor = Cursors.Hand;
        button.FlatAppearance.MouseOverBackColor = Color.FromArgb(38, 44, 56);
        button.FlatAppearance.MouseDownBackColor = Color.FromArgb(50, 58, 72);
    }
}
