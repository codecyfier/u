using System.Diagnostics;
using System.Security.Principal;
using OkitaInstalleurOffice.Classes;
using OkitaInstalleurOffice.Forms;

namespace OkitaInstalleurOffice;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        RegisterGlobalErrorHandling();
        Logger.Info("Démarrage de l'application.");

        if (!IsAdministrator())
        {
            RelaunchAsAdministrator();
            return;
        }

        Application.Run(new SplashForm());
    }

    /// <summary>
    /// Capture toute exception non gérée (thread UI, tâches en arrière-plan, threads bruts)
    /// pour éviter un plantage silencieux : on journalise systématiquement et on prévient
    /// l'utilisateur avec un message clair plutôt qu'un crash muet.
    /// </summary>
    private static void RegisterGlobalErrorHandling()
    {
        Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
        Application.ThreadException += (_, args) => HandleFatal("Erreur inattendue dans l'interface", args.Exception);
        AppDomain.CurrentDomain.UnhandledException += (_, args) =>
        {
            if (args.ExceptionObject is Exception exception) HandleFatal("Erreur système inattendue", exception);
        };
        TaskScheduler.UnobservedTaskException += (_, args) =>
        {
            Logger.Error("Exception non observée dans une tâche en arrière-plan", args.Exception);
            args.SetObserved();
        };
    }

    private static void HandleFatal(string context, Exception exception)
    {
        Logger.Error(context, exception);
        var message = $"{context} :\n{exception.Message}\n\nLe détail complet a été enregistré dans :\n{Logger.FilePath}";
        try
        {
            MessageBox.Show(message, "okitaInstalleur Office - Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        catch
        {
            // Si même l'affichage du message échoue, on ne fait rien de plus : l'erreur est déjà journalisée.
        }
    }

    private static void RelaunchAsAdministrator()
    {
        try
        {
            var startInfo = new ProcessStartInfo
            {
                FileName = Environment.ProcessPath ?? Application.ExecutablePath,
                UseShellExecute = true,
                Verb = "runas"
            };
            Process.Start(startInfo);
        }
        catch (System.ComponentModel.Win32Exception exception) when (exception.NativeErrorCode == 1223)
        {
            // L'utilisateur a explicitement refusé l'invite UAC : ce n'est pas une erreur système,
            // on l'informe simplement que l'installation nécessite ces droits.
            Logger.Info("L'utilisateur a refusé l'élévation UAC.");
            MessageBox.Show("Les droits administrateur sont nécessaires pour installer Office. Relancez l'application et acceptez l'invite de sécurité Windows.", "Droits requis", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        catch (Exception exception)
        {
            Logger.Error("Échec de la relance en administrateur", exception);
            MessageBox.Show($"Impossible de relancer l'application avec les droits administrateur : {exception.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private static bool IsAdministrator()
    {
        using var identity = WindowsIdentity.GetCurrent();
        var principal = new WindowsPrincipal(identity);
        return principal.IsInRole(WindowsBuiltInRole.Administrator);
    }
}
